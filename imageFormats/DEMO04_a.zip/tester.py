#demo script
print('Hello Mike, Grant, Don')
import sys
print(sys.path)


try:
  import numpy as np
  print('numpy ',np.version.version)
  import cv2
  print('opencv', cv2.__version__)

except:
 print('no opencv/numpy')
