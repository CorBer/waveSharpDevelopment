import laz_vars as vars

#print(vars.filename)
filename= vars.filename.decode('ASCII')
print(filename)

try:
  import cv2
  openCV=True
  import numpy as np
except:
  print('opencv is NOT installed')
  openCV=False


if openCV:
  loadImage=cv2.imread(filename).astype('float64')
  loadImage/=loadImage.max()
  loadImage*=65535
  loadImage=loadImage.astype(np.uint16)
  vars.transferW=loadImage.shape[0]
  vars.transferH=loadImage.shape[1]
  vars.transferC=3 #default 3 channels
