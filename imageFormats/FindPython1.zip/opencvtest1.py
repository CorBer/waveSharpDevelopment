import laz_vars as vars

#print(vars.filename)
filename= vars.filename.decode('ASCII')
print(filename)

try:
  import cv2
  openCV=True
  import numpy as np
except:
  print('opencv is NOT installed')
  openCV=False


if openCV:
  gaussian_kernel=5
  gaussian_sigma=3
  loadImage=cv2.imread(filename).astype('float64')
  loadImage/=loadImage.max()
  loadImage=cv2.GaussianBlur(loadImage,(gaussian_kernel, gaussian_kernel),gaussian_sigma ,).astype('float64')
  loadImage*=65535
  loadImage=loadImage.astype(np.uint16)
  vars.transferW=loadImage.shape[0]
  vars.transferH=loadImage.shape[1]
  vars.transferC=3 #default 3 channels
