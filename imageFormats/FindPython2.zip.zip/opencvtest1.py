import laz_vars as vars
#20240726
#print(vars.filename)
filename= vars.filename.decode('ASCII')
#print(filename)
print('** CONVOLVE **')
if imageLoaded:
  gaussian_kernel=0
  gaussian_sigma=vars.sigma
  clipHi=loadImage.max()
  clipLo=loadImage.min()
  if vars.filterchange:
    print('*** FILTERUPDATE ***')
    blur=cv2.GaussianBlur(loadImage,(gaussian_kernel, gaussian_kernel),gaussian_sigma ,).astype('float64')
    highpass=cv2.subtract(loadImage,blur)

  dispImage = cv2.addWeighted(loadImage, 1, highpass, 1+vars.sharpen1/10, 0)
  dispImage=np.clip(dispImage,clipLo,clipHi)
  dispImage/=dispImage.max()

  dispImage*=65535
  dispImage=dispImage.astype(np.uint16)
  vars.transferW=dispImage.shape[0]
  vars.transferH=dispImage.shape[1]
  vars.transferC=3 #default 3 channels
else:
  print('!!! Image not loaded !!')
