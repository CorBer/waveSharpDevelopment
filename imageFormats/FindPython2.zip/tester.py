#demo script
print('Hello Mike, Grant, Don')
import sys
print(sys.path)

import pkg_resources
installed_packages = pkg_resources.working_set
installed_packages_list = sorted(["%s==%s" % (i.key, i.version)
   for i in installed_packages])
print(installed_packages_list)

try:
  import numpy as np
  print('test')
  print('numpy ',np.version.version)
  import cv2
  print('opencv', cv2.__version__)

except:
 print('no opencv/numpy')
