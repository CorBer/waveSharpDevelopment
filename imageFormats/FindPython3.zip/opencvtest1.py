import laz_vars as vars
#20240726
#print(vars.filename)
filename= vars.filename.decode('ASCII')
#print(filename)
print('** CONVOLVE **')
if imageLoaded:
  if vars.fastcalc:
    gaussian_kernel=3
  else:
    gaussian_kernel=0

  clipHi=loadImage.max()
  clipLo=loadImage.min()
  if vars.filterchange:
    print('*** FILTERUPDATE ***')
    blur1=cv2.GaussianBlur(loadImage,(gaussian_kernel, gaussian_kernel),vars.sigma1 ,).astype('float64')
    highpass1=cv2.subtract(loadImage,blur1).astype('float64')
    blur2=cv2.GaussianBlur(blur1,(gaussian_kernel, gaussian_kernel),vars.sigma2 ,).astype('float64')
    highpass2=cv2.subtract(blur1,blur2).astype('float64')
    blur3=cv2.GaussianBlur(blur2,(gaussian_kernel, gaussian_kernel),vars.sigma3 ,).astype('float64')
    highpass3=cv2.subtract(blur2,blur3).astype('float64')

  dispImage = cv2.addWeighted(blur3,    1,  highpass1, 1+vars.sharpen1/10, 0)
  dispImage = cv2.addWeighted(dispImage, 1, highpass2, 1+vars.sharpen2/10, 0)
  dispImage = cv2.addWeighted(dispImage, 1, highpass3, 1+vars.sharpen2/10, 0)

  dispImage=np.clip(dispImage,clipLo,clipHi)
  cv2.normalize(dispImage, dispImage, 0, 65535, cv2.NORM_MINMAX)
  dispImage=dispImage.astype(np.uint16)
  vars.transferW=dispImage.shape[0]
  vars.transferH=dispImage.shape[1]
  vars.transferC=3 #default 3 channels
else:
  print('!!! Image not loaded !!')

