import laz_vars as vars
#20240726
#print(vars.filename)
filename= vars.filename.decode('ASCII')
#print(filename)
if vars.useROI:
  print('** ROI-CONVOLVE **')
else:
  print('** CONVOLVE **')


if imageLoaded:
  if vars.fastcalc:
    gaussian_kernel=3
  else:
    gaussian_kernel=0

  clipHi=loadImage.max()
  clipLo=loadImage.min()

  sectionY=slice(vars.procL,vars.procL+vars.procW);
  sectionX=slice(vars.procT,vars.procT+vars.procH);


  print(sectionX, sectionY)

  if vars.filterchange:
    if vars.filterROI:
      print('*** ROI-FILTERUPDATE ***')

      blur1=cv2.GaussianBlur(loadImage[sectionX,sectionY],(gaussian_kernel, gaussian_kernel),vars.sigma1 ,).astype('float64')
      highpass1=loadImage.copy()
      highpass1[sectionX,sectionY]=cv2.subtract(loadImage[sectionX,sectionY],blur1).astype('float64')
      blur2=cv2.GaussianBlur(blur1,(gaussian_kernel, gaussian_kernel),vars.sigma2 ,).astype('float64')
      highpass2=loadImage.copy()
      highpass2[sectionX,sectionY]=cv2.subtract(blur1,blur2).astype('float64')
      blur3=loadImage.copy()
      blur3[sectionX,sectionY]=cv2.GaussianBlur(blur2,(gaussian_kernel, gaussian_kernel),vars.sigma3 ,).astype('float64')
      highpass3=loadImage.copy()
      highpass3[sectionX,sectionY]=cv2.subtract(blur2,blur3[sectionX,sectionY]).astype('float64')


    else:
      blur1=cv2.GaussianBlur(loadImage,(gaussian_kernel, gaussian_kernel),vars.sigma1 ,).astype('float64')
      highpass1=cv2.subtract(loadImage,blur1).astype('float64')
      blur2=cv2.GaussianBlur(blur1,(gaussian_kernel, gaussian_kernel),vars.sigma2 ,).astype('float64')
      highpass2=cv2.subtract(blur1,blur2).astype('float64')
      blur3=cv2.GaussianBlur(blur2,(gaussian_kernel, gaussian_kernel),vars.sigma3 ,).astype('float64')
      highpass3=cv2.subtract(blur2,blur3).astype('float64')

  if vars.useROI:
    dispImage=blur3.copy()
    ROI = cv2.addWeighted(blur3[sectionX,sectionY],    1,  highpass1[sectionX,sectionY], 1+vars.sharpen1/10, 0)
    ROI = cv2.addWeighted(ROI, 1, highpass2[sectionX,sectionY], 1+vars.sharpen2/10, 0)
    ROI = cv2.addWeighted(ROI, 1, highpass3[sectionX,sectionY], 1+vars.sharpen2/10, 0)
    dispImage[sectionX,sectionY]=ROI
  else:
    dispImage = cv2.addWeighted(blur3,    1,  highpass1, 1+vars.sharpen1/10, 0)
    dispImage = cv2.addWeighted(dispImage, 1, highpass2, 1+vars.sharpen2/10, 0)
    dispImage = cv2.addWeighted(dispImage, 1, highpass3, 1+vars.sharpen2/10, 0)

  dispImage=np.clip(dispImage,clipLo,clipHi)
  cv2.normalize(dispImage, dispImage, 0, 65535, cv2.NORM_MINMAX)
  dispImage=dispImage.astype(np.uint16)
  vars.transferW=dispImage.shape[0]
  vars.transferH=dispImage.shape[1]
  vars.transferC=3 #default 3 channels
else:
  print('!!! Image not loaded !!')



