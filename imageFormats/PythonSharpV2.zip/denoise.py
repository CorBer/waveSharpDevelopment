import laz_vars as vars

filename= vars.filename.decode('ASCII')

img = cv2.imread(filename, cv2.IMREAD_GRAYSCALE)
print('img ',img.shape)
t=[]
t.append(('start',time.monotonic()))

dft = cv2.dft(np.float32(img),flags = cv2.DFT_COMPLEX_OUTPUT)
t.append(('dft',time.monotonic()))
dft_shift = np.fft.fftshift(dft)
t.append(('shift',time.monotonic()))

rows, cols = img.shape
crow, ccol = rows//2, cols//2

# create a mask first, center square is 1, remaining all zeros
mask = np.zeros((rows,cols,2),np.uint8)
minradius=min(rows,cols)//4
mask[crow-minradius:crow+minradius, ccol-minradius:ccol+minradius] = 1
t.append(('mask',time.monotonic()))

# apply mask and inverse DFT
fshift = dft_shift*mask
f_ishift = np.fft.ifftshift(fshift)
t.append(('ifftshift',time.monotonic()))

img_back = cv2.idft(f_ishift)
t.append(('idft',time.monotonic()))

dispImage=cv2.normalize(img_back[:,:,0], None, 0, 255, cv2.NORM_MINMAX, cv2.CV_32F)
t.append(('normalize',time.monotonic()))

print(dispImage.shape)
vars.transferC=1 #default 3 channels

dispImage=dispImage.astype(np.uint8)
t.append(('8bit',time.monotonic()))

last=t[0][1]
first=last
print(last)
for point in t:
  print(point[0],int((point[1]-last)*1000000))
  last=point[1]
print('total ',(last-first)*1000000)



