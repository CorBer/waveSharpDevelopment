import laz_vars as vars
import time
t=[]
t.append(('start',time.monotonic()))

#20240726
#print(vars.filename)
filename= vars.filename.decode('ASCII')
#print(filename)
if vars.useROI:
  print('** ROI-CONVOLVE **')
else:
  print('** CONVOLVE **')


if imageLoaded:
  t.append(('loaded',time.monotonic()))

  if vars.fastcalc:
    gaussian_kernel=3
  else:
    gaussian_kernel=0

  sectionY=slice(vars.procL,vars.procL+vars.procW);
  sectionX=slice(vars.procT,vars.procT+vars.procH);
  if vars.procW==0:
    vars.useROI=False
  if vars.procH==0:
    vars.useROI=False

  #clips prevent overlit/too dark

  if vars.useROI and vars.ROImove:
    ROIclipHi=loadImage[sectionX,sectionY].max()
    ROIclipLo=loadImage[sectionX,sectionY].min()
    t.append(('ROIClip',time.monotonic()))

  print(sectionX, sectionY)
  t.append(('beforefilters',time.monotonic()))

  if vars.filterchange:
    if vars.filterROI:
      print('*** ROI-FILTERUPDATE ***')
      t.append(('ROIFilter',time.monotonic()))
      blur1=cv2.GaussianBlur(loadImage[sectionX,sectionY],(gaussian_kernel, gaussian_kernel),vars.sigma1 ,).astype('float32')
      highpass1=loadImage.copy()
      highpass1[sectionX,sectionY]=cv2.subtract(loadImage[sectionX,sectionY],blur1).astype('float32')
      t.append(('layer1',time.monotonic()))

      blur2=cv2.GaussianBlur(blur1,(gaussian_kernel, gaussian_kernel),vars.sigma2 ,).astype('float32')
      highpass2=loadImage.copy()

      highpass2[sectionX,sectionY]=cv2.subtract(blur1,blur2).astype('float32')
      t.append(('layer2',time.monotonic()))

      fblur=loadImage.copy()
      fblur[sectionX,sectionY]=cv2.GaussianBlur(blur2,(gaussian_kernel, gaussian_kernel),vars.sigma3 ,).astype('float32')
      highpass3=loadImage.copy()

      highpass3[sectionX,sectionY]=cv2.subtract(blur2,fblur[sectionX,sectionY]).astype('float32')
      t.append(('layer3',time.monotonic()))


    else:
      t.append(('Filter',time.monotonic()))
      fblur=cv2.GaussianBlur(loadImage,(gaussian_kernel, gaussian_kernel),vars.sigma1 ,).astype('float32')
      highpass1=cv2.subtract(loadImage,fblur).astype('float32')
      t.append(('layer1',time.monotonic()))

      blur1=cv2.GaussianBlur(fblur,(gaussian_kernel, gaussian_kernel),vars.sigma2 ,).astype('float32')
      highpass2=cv2.subtract(fblur,blur1).astype('float32')
      t.append(('layer1',time.monotonic()))

      fblur=cv2.GaussianBlur(blur1,(gaussian_kernel, gaussian_kernel),vars.sigma3 ,).astype('float32')
      highpass3=cv2.subtract(blur1,fblur).astype('float32')
      t.append(('layer3',time.monotonic()))


  if vars.useROI:
    t.append(('useROI',time.monotonic()))
    #dispImage=blur3.copy()
    #t.append(('blurcopy',time.monotonic()))
    ROI = cv2.addWeighted(fblur[sectionX,sectionY],1,  highpass1[sectionX,sectionY], 1+vars.sharpen1/10, 0)
    t.append(('ROI1',time.monotonic()))

    ROI = cv2.addWeighted(ROI, 1, highpass2[sectionX,sectionY], 1+vars.sharpen2/10, 0)
    t.append(('ROI2',time.monotonic()))

    ROI = cv2.addWeighted(ROI, 1, highpass3[sectionX,sectionY], 1+vars.sharpen2/10, 0)
    t.append(('ROI3',time.monotonic()))

    ROI=np.clip(ROI,ROIclipLo,ROIclipHi)
    t.append(('clip',time.monotonic()))

    outImage[sectionX,sectionY]=ROI
    t.append(('outImg',time.monotonic()))


  else:
    t.append(('enhance',time.monotonic()))

    outImage = cv2.addWeighted(fblur,    1,  highpass1, 1+vars.sharpen1/10, 0)
    t.append(('enhance1',time.monotonic()))
    outImage = cv2.addWeighted(outImage, 1, highpass2, 1+vars.sharpen2/10, 0)
    t.append(('enhance2',time.monotonic()))

    outImage = cv2.addWeighted(outImage, 1, highpass3, 1+vars.sharpen2/10, 0)
    t.append(('outImage',time.monotonic()))

    outImage=np.clip(outImage,clipLo,clipHi)
    t.append(('clip',time.monotonic()))

  dispImage=cv2.normalize(outImage, None, 0, 255, cv2.NORM_MINMAX, cv2.CV_32F)
  t.append(('normalize',time.monotonic()))

  dispImage=dispImage.astype(np.uint8)
  t.append(('8bit',time.monotonic()))

  vars.transferW=dispImage.shape[0]
  vars.transferH=dispImage.shape[1]
  vars.transferC=3 #default 3 channels
else:
  print('!!! Image not loaded !!')

last=t[0][1]
print(last)
for point in t:
  print(point[0],int((point[1]-last)*1000000))
  last=point[1]


