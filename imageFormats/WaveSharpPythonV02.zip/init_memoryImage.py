import laz_vars as vars
from dataclasses import dataclass

#20240804 
import numpy as np
import cv2

import time

gauss=2.35*np.sqrt(np.pi)

Models=['HLS','OKlab']

Cmodel=Models[0] #HLS

@dataclass
class ToneControl:
    name: str
    m: float
    m_1: float =0
    m2_1: float =0
    def calc(self, m):
        self.m=m
        self.m_1=self.m-1
        self.m2_1=2*self.m-1
    def __post_init__(self):
        self.calc(self.m)
        print(f"ToneControl {self.name} m={self.m} m1={self.m_1} m2={self.m2_1}")
 

verbose=False
def showmem():
    cv2.imshow('mem_image',mem_image)

def showdisp():
    cv2.imshow('disp_image',disp_image)

def showout():
    cv2.imshow('image',out_image)

def setBase():
      global mem_image,base, ccBase, L_channel, S_channel, ccModel
      base=mem_image.astype('float32')
     
      vars.clipLo=base.min()
      vars.clipHi=base.max()
      
      base=base/65535
      #L_channel=0
      #Base2ccModel()
      if Cmodel=='HLS':
        L_channel=1
        S_channel=2
        ccBase = cv2.cvtColor(base, cv2.COLOR_BGR2HLS)
        ccBase[:,:,L_channel]=base[:,:,0]*0.299+base[:,:,1]*0.587+base[:,:,2]*0.114;
        ccModel=ccBase.copy()
        print('HLS ccModel ',ccModel[:,:,L_channel].max())
    
      if Cmodel=='OKlab':
        L_channel=0
        S_channel=2
        RGB2OKLab()
        print('OKlab ccModel ',ccModel[:,:,L_channel].max())


def setLtone(L):
    m = 1-L
    m_1 = m - 1
    m2_1 = 2 * m - 1
    return m_1, m2_1,m

def setStone(S):
    m = 1-S
    m_1 = m - 1
    m2_1 = 2 * m - 1
    return m_1, m2_1,m

def setdisp():
    global out_image
    disp_image=out_image.copy()
    disp_image*=65535
    disp_image=disp_image.astype(np.uint16)
    print('dispsum',disp_image.sum())
    return disp_image

def RGB2OKLab():
    global base,ccModel,ccBase
    #BGR
    La= base[:,:,0]*0.0514459929+base[:,:,1]*0.5363325363+base[:,:,2]*0.4122214708
    Ma= base[:,:,0]*0.1073969566+base[:,:,1]*0.6806995451+base[:,:,2]*0.2119034982
    Sa= base[:,:,0]*0.6299787005+base[:,:,1]*0.2817188376+base[:,:,2]*0.0883024619
    
    La=np.cbrt(La)
    Ma=np.cbrt(Ma)
    Sa=np.cbrt(Sa)
    
    okL=0.2104542553*La+0.793617785*Ma-0.0040720468*Sa
    oka=1.9779984951*La-2.428592205*Ma+0.4505937099*Sa
    okb=0.0259040371*La+0.7827717662*Ma - 0.8086757660*Sa
    
    #OKl=(base[:,:,0]*0.299+base[:,:,1]*0.587+base[:,:,2]*0.168)
    ccModel[:,:,0]=okL
    ccModel[:,:,1]=oka
    ccModel[:,:,2]=okb
    ccBase=ccModel.copy()

def OKlab2RGB():
    global ccBase, out_image
    c1=0.3963377921737678568 
    c2=0.1055613423236563494
    c3=0.0894841820949657597
    c4=0.2158037580607588034
    c5=0.0638541747717059034
    c6=1.2914855378640917399
    #t0=time.monotonic()
    ccBase[:,:,0]=np.clip(ccBase[:,:,0],0,1)
    L = (ccBase[:,:,0]   + c1  * ccBase[:,:,1]  + c4   * ccBase[:,:,2])
    M = (ccBase[:,:,0]   - c2 * ccBase[:,:,1]  - c5   * ccBase[:,:,2])
    S = (ccBase[:,:,0]   - c3 * ccBase[:,:,1]  - c6   * ccBase[:,:,2])
    #t1=time.monotonic()
    #print('LMS',t1-t0)
    L=L*L*L
    M=M*M*M
    S=S*S*S
    #L,M,S=np.power([L,M,S],3)
    #t0=time.monotonic()
    #print('cbrt', t0-t1)

    #RED/GREEN/BLUE    
    out_image[:,:,2]=   +4.076741661347994*L-3.307711590408193*M+0.230969928729428*S
    out_image[:,:,1]=	-1.2684380040921763*L+2.6097574006633715*M-0.3413193963102197*S
    out_image[:,:,0]=   -0.004196086541837188*L-0.7034186144594493*M+1.7076147009309444*S

    


#RGB CONVOLVE   
def RGBsharpen():
    global base, out_image, mem_image, blur1,blur2, blur3, highpass1, highpass2, highpass3,disp_image
    gaussian_kernel=3
    gaussian_sigma1=vars.sigma1*gauss #conversion between wavesharp and cv2 gaussian
    gaussian_sigma2=vars.sigma2*gauss #conversion between wavesharp and cv2 gaussian
    gaussian_sigma3=vars.sigma3*gauss #conversion between wavesharp and cv2 gaussian
    
    if vars.filterchange:
        blur1=cv2.GaussianBlur(base,(gaussian_kernel, gaussian_kernel),gaussian_sigma1 ,).astype('float32')
        highpass1=cv2.subtract(base,blur1).astype('float32')
        blur2=cv2.GaussianBlur(blur1,(gaussian_kernel, gaussian_kernel),gaussian_sigma2 ,).astype('float32')
        highpass2=cv2.subtract(blur1,blur2).astype('float32')
        blur3=cv2.GaussianBlur(blur2,(gaussian_kernel, gaussian_kernel),gaussian_sigma3 ,).astype('float32')
        highpass3=cv2.subtract(blur2,blur3).astype('float32')

    vars.filterchange=False    
    #out_image=base+highpass1*vars.sharpen1
    #image is fully based on the original
    out_image =cv2.addWeighted(blur3, 1,  highpass1,vars.sharpen1, 0)
    if vars.sharpen2>0:
        out_image=cv2.addWeighted(out_image, 1,  highpass2,vars.sharpen2, 0)
    if vars.sharpen3>0:
        out_image =cv2.addWeighted(out_image, 1,  highpass3,vars.sharpen3, 0)
    out_image*=65535
    disp_image=np.clip(out_image,vars.clipLo,vars.clipHi)
    disp_image= cv2.normalize(disp_image,None,0,65535,cv2.NORM_MINMAX).astype('uint16')

    #out_image=np.clip(out_image,vars.clipLo,vars.clipHi)
    #out_image= cv2.normalize(out_image,None,0,65535,cv2.NORM_MINMAX)
    # print('checksum out_image ',out_image.sum())
    # print('out_image Lo',vars.clipLo)
    # print('out_image Hi',vars.clipHi)


def tonemap(tone, channel, image):
    image[:,:,channel]=(image[:,:,channel]*tone.m_1)/(image[:,:,channel]*tone.m2_1-tone.m)

#LUMCONVOLVE       
def LUMsharpen():
    global ccBase, ccModel, out_image, mem_image, blur1,blur2, blur3, highpass1, highpass2, highpass3, disp_image,L_channel, b_hist, r_hist, g_hist, l_hist

    gaussian_kernel=5
    print('lo=hi ',vars.L_lo,' - ',vars.L_hi)
    lowL=vars.L_lo/65535
    highL=vars.L_hi/65535
    deltaL=highL-lowL
      
    gaussian_sigma1=vars.sigma1*gauss #conversion between wavesharp and cv2 gaussian
    gaussian_sigma2=vars.sigma2*gauss #conversion between wavesharp and cv2 gaussian
    gaussian_sigma3=vars.sigma3*gauss #conversion between wavesharp and cv2 gaussian
    print('Lmax ',ccModel[:,:,L_channel].max())

     #ccModel is the reference and uses an L_channel that will be sharpened 
    if vars.filterchange:
        blur1=cv2.GaussianBlur(ccModel[:,:,L_channel],(gaussian_kernel, gaussian_kernel),gaussian_sigma1 ,).astype('float32')
        highpass1=cv2.subtract(ccModel[:,:,L_channel],blur1).astype('float32')
        blur2=cv2.GaussianBlur(blur1,(gaussian_kernel, gaussian_kernel),gaussian_sigma2 ,).astype('float32')
        highpass2=cv2.subtract(blur1,blur2).astype('float32')
        blur3=cv2.GaussianBlur(blur2,(gaussian_kernel, gaussian_kernel),gaussian_sigma3 ,).astype('float32')
        highpass3=cv2.subtract(blur2,blur3).astype('float32')

    vars.filterchange=False    
    #create enhanced version again based on ccModel L as a base 
    ccBase[:,:,L_channel] = blur3.copy()
    if vars.layer1==True:
        ccBase[:,:,L_channel]+=highpass1*vars.sharpen1
    if vars.layer2==True:
            ccBase[:,:,L_channel]=cv2.addWeighted(ccBase[:,:,L_channel], 1.0,  highpass2,vars.sharpen2, 0)
    if vars.layer3==True:
        ccBase[:,:,L_channel] =cv2.addWeighted(ccBase[:,:,L_channel], 1.0,  highpass3,vars.sharpen3, 0)
    print('Lmax ',ccBase[:,:,L_channel].max())

    #Apply LUMINANCE
    if vars.L_tone!=0.5:   
        lum.calc(1-vars.L_tone)
        tonemap(lum,L_channel,ccBase)

    #normalize
    ccBase[:,:,L_channel]-=lowL
    ccBase[:,:,L_channel]/=deltaL

    #L need to be in the 0..1 range before the conversion to RGB
    ccBase[:,:,L_channel]=np.clip(ccBase[:,:,L_channel],0,1)
    
    #Apply SATURATION   
    if vars.S_tone!=0.5:   
        sat.calc(1-vars.S_tone)
        #copy original S channel and enhance
        ccBase[:,:,S_channel]=ccModel[:,:,S_channel] #HLS and OKlab use S=2
        tonemap(sat,S_channel,ccBase)
    
        if Cmodel=='OKlab':  
           ccBase[:,:,1]=ccModel[:,:,1]
           tonemap(sat,1,ccBase)
    
    #Apply GAMMA on L channel
    if vars.Gamma!=1:
        ccBase[:,:,L_channel]=np.power(ccBase[:,:,L_channel],vars.Gamma)
    
    #conversion to RGB
    if Cmodel=='HLS':
       ccBase[:,:,S_channel]=np.clip(ccBase[:,:,S_channel],0,1)
       out_image = cv2.cvtColor(ccBase, cv2.COLOR_HLS2BGR)
    
    if Cmodel=='OKlab':
       ccBase[:,:,S_channel]=np.clip(ccBase[:,:,S_channel],0,1)
    #   ccBase[:,:,1]=np.clip(ccBase[:,:,1],0,1)
       OKlab2RGB();
    
    #BGR arranged data
    if vars.R_tone!=0.5:   
        redtone.calc(1-vars.R_tone)
        tonemap(redtone,2,out_image)
    if vars.G_tone!=0.5:   
        greentone.calc(1-vars.G_tone)
        tonemap(greentone,1,out_image)
    if vars.B_tone!=0.5:   
        bluetone.calc(1-vars.B_tone)
        tonemap(bluetone,0,out_image)
  
    out_image=np.clip(out_image,0,1)
    #convert to 16bit RGB
    out_image *=65535

    disp_image=out_image.astype('uint16') 
    l_hist = cv2.calcHist([ccBase], [L_channel], None, [65535], [0,1])
    #BGR
    b_hist = cv2.calcHist([disp_image], [0], None, [65535], [0,65535])
    g_hist = cv2.calcHist([disp_image], [1], None, [65535], [0,65535])
    r_hist = cv2.calcHist([disp_image], [2], None, [65535], [0,65535])
      
    
    

memimg_loaded=False
try:
  print(vars.difdimy)
  print(vars.difdimx)
  mem_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.uint16)  
  
  disp_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.uint16)  
  base=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  ccBase=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  ccModel=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  out_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  blur1=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  blur2=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  blur3=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  highpass1=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  highpass2=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  highpass3=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  b_hist=np.zeros(65535).astype(np.float32)
  g_hist=np.zeros(65535).astype(np.float32)
  r_hist=np.zeros(65535).astype(np.float32)
  l_hist=np.zeros(65535).astype(np.float32)
  
  vars.clipLo=0
  vars.clipHi=65535
  print('image initialized')
  print(mem_image.shape)
  print('sum',mem_image.sum())
  mem_image_loaded=True
  lum=ToneControl(name='lum',m=0.5)
  sat=ToneControl(name='sat',m=0.5)
  redtone=ToneControl(name='red',m=0.5)
  greentone=ToneControl(name='green',m=0.5)
  bluetone=ToneControl(name='blue',m=0.5)
 



except:
  print('image NOT initialized')


