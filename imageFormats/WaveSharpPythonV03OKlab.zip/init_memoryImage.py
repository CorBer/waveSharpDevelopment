import laz_vars as vars
from dataclasses import dataclass

#20240804 
import numpy as np
import cv2

import time

gauss=2.35*np.sqrt(np.pi)

Models=['HSV','HLS','OKlab']

Cmodel=Models[2] #OKLab

Blurs=['Gauss','Bilat']
Blurmode=Blurs[0]

@dataclass
class Gaussians:
    s1: float =0.1
    s2: float =0.1
    s3: float =0.1
    gaussC: float =2.35*np.sqrt(np.pi)
    kernel: int = 0
    def calc(self):
        self.s1=vars.sigma1*self.gaussC #conversion between wavesharp and cv2 gaussian
        self.s2=vars.sigma2*self.gaussC #conversion between wavesharp and cv2 gaussian
        self.s=vars.sigma3*self.gaussC #conversion between wavesharp and cv2 gaussian

    def __post_init__(self):
        self.s1=vars.sigma1*self.gaussC #conversion between wavesharp and cv2 gaussian
        self.s2=vars.sigma2*self.gaussC #conversion between wavesharp and cv2 gaussian
        self.s3=vars.sigma3*self.gaussC #conversion between wavesharp and cv2 gaussian
        #print(self)
 

@dataclass
class ToneControl:
    name: str
    m: float
    m_1: float =0
    m2_1: float =0
    def calc(self, m):
        self.m=m
        self.m_1=self.m-1
        self.m2_1=2*self.m-1

    def __post_init__(self):
        self.calc(self.m)
        print(self)
 
verbose=False

def setBase():
      global mem_image,base, ccBase, L_channel, S_channel, ccModel
      base=mem_image.astype('float32')
      vars.clipLo=base.min()
      vars.clipHi=base.max()
      
      if base.max()>512: #check for 16bit data
         base=base/65535
      else:
          base=base/255   

      if Cmodel=='HLS':
        L_channel=1
        S_channel=2
        ccBase = cv2.cvtColor(base, cv2.COLOR_BGR2HLS)
        ccBase[:,:,L_channel]=base[:,:,0]*0.299+base[:,:,1]*0.587+base[:,:,2]*0.114;
        ccModel=ccBase.copy()
        print('HLS ccModel ',ccModel[:,:,L_channel].max())
      
      if Cmodel=='HSV':
        L_channel=2
        S_channel=1
        ccBase = cv2.cvtColor(base, cv2.COLOR_BGR2HSV)
        ccBase[:,:,L_channel]=base[:,:,0]*0.299+base[:,:,1]*0.587+base[:,:,2]*0.114;
        ccModel=ccBase.copy()
        print('HSV ccModel ',ccModel[:,:,L_channel].max())
      
      if Cmodel=='OKlab':
        L_channel=0
        S_channel=2
        linear_srgb_to_oklab(base)
        #RGB2OKLab()
          
        print('OKlab ccModel ',ccModel[:,:,L_channel].max())


def setdisp():
    global out_image
    disp_image=out_image.copy()
    disp_image*=65535
    disp_image=disp_image.astype(np.uint16)
    print('dispsum',disp_image.sum())
    return disp_image


def linear_srgb_to_oklab(c):
    global ccModel, ccBase
    l = 0.4121656120 * c[:,:,2] + 0.5362752080 * c[:,:,1] + 0.0514575653 * c[:,:,0]
    m = 0.2118591070 * c[:,:,2] + 0.6807189584 * c[:,:,1] + 0.1074065790 * c[:,:,0]
    s = 0.0883097947 * c[:,:,2] + 0.2818474174 * c[:,:,1] + 0.6302613616 * c[:,:,0]

    l_ = l**(1./3.)
    m_ = m**(1./3.)
    s_ = s**(1./3.)

    okL=	0.2104542553*l_ + 0.7936177850*m_ - 0.0040720468*s_
    oka=	1.9779984951*l_ - 2.4285922050*m_ + 0.4505937099*s_
    okb=	0.0259040371*l_ + 0.7827717662*m_ - 0.8086757660*s_

    ccModel[:,:,0]=np.power(okL,2.4)
    ccModel[:,:,1]=oka
    ccModel[:,:,2]=okb
    ccBase=ccModel.copy()

def oklab_to_linear_srgb(c):
    global out_image
    c[:,:,0]=np.power(c[:,:,0],1/2.4)

    l_ = c[:,:,0] + 0.3963377774 * c[:,:,1] + 0.2158037573 * c[:,:,2]
    m_ = c[:,:,0] - 0.1055613458 * c[:,:,1] - 0.0638541728 * c[:,:,2]
    s_ = c[:,:,0] - 0.0894841775 * c[:,:,1] - 1.2914855480 * c[:,:,2]

    l = l_*l_*l_
    m = m_*m_*m_
    s = s_*s_*s_

    out_image[:,:,2]=	+ 4.0767245293*l - 3.3072168827*m + 0.2307590544*s
    out_image[:,:,1]=	- 1.2681437731*l + 2.6093323231*m - 0.3411344290*s
    out_image[:,:,0]=	- 0.0041119885*l - 0.7034763098*m + 1.7068625689*s
	

def tonemap(tone, channel, image):
    image[:,:,channel]=(image[:,:,channel]*tone.m_1)/(image[:,:,channel]*tone.m2_1-tone.m)


def calcHistogram():
    global ccBase, disp_image,L_channel, b_hist, r_hist, g_hist, l_hist
    l_hist = cv2.calcHist([ccModel], [L_channel], None, [65535], [0,1])
    #BGR
    b_hist = cv2.calcHist([disp_image], [0], None, [65535], [0,65535])
    g_hist = cv2.calcHist([disp_image], [1], None, [65535], [0,65535])
    r_hist = cv2.calcHist([disp_image], [2], None, [65535], [0,65535])
    
def GaussBlur(img):
    global highpass1, highpass2, highpass3, blur3
    g=Gaussians()    
    blur1=cv2.GaussianBlur(img,(g.kernel, g.kernel),g.s1,).astype('float32')
    highpass1=cv2.subtract(img,blur1).astype('float32')
    blur2=cv2.GaussianBlur(blur1,(g.kernel, g.kernel),g.s2 ,).astype('float32')
    highpass2=cv2.subtract(blur1,blur2).astype('float32')
    blur3=cv2.GaussianBlur(blur2,(g.kernel, g.kernel),g.s3 ,).astype('float32')
    highpass3=cv2.subtract(blur2,blur3).astype('float32')
    vars.filterchange=False    

    
def BilatBlur(img):
    global highpass1, highpass2, highpass3, blur3
    r=vars.Bilatr
    g=Gaussians()
    blur1=cv2.bilateralFilter(img,-1,g.s1 ,r).astype('float32')
    highpass1=cv2.subtract(img,blur1).astype('float32')
    blur2=cv2.bilateralFilter(blur1,-1,g.s2 ,r).astype('float32')
    highpass2=cv2.subtract(blur1,blur2).astype('float32')
    blur3=cv2.bilateralFilter(blur2,-1,g.s3 ,r).astype('float32')
    highpass3=cv2.subtract(blur2,blur3).astype('float32')  
    vars.filterchange=False    


def Sharpen():
    img = blur3.copy()
    if vars.layer1==True:
        img+=highpass1*vars.sharpen1
    if vars.layer2==True:
        img+=highpass2*vars.sharpen2
    if vars.layer3==True:
        img+=highpass3*vars.sharpen3
    return img    
    
def applyGamma():
     global ccModel,L_channel
     if vars.Gamma!=1:
        ccModel[:,:,L_channel]= np.power(ccModel[:,:,L_channel],1/vars.Gamma)    


def applySaturation():
    global ccModel, ccBase, S_channel
    if vars.S_tone!=0.5:   
        sat.calc(1-vars.S_tone)
        #copy original S channel and enhance
        ccModel[:,:,S_channel]=ccBase[:,:,S_channel] #HLS and OKlab use S=2
        tonemap(sat,S_channel,ccModel)
        ccModel[:,:,S_channel]=np.clip(ccModel[:,:,S_channel],0,1)
        if Cmodel=='OKlab':  #in OKLab also tone channel 1
           ccModel[:,:,1]=ccBase[:,:,1]
           tonemap(sat,1,ccModel)
           ccModel[:,:,1]=np.clip(ccModel[:,:,1],0,1)
        

def applyClip(cliplo, cliphi,img):
    lowL=cliplo/65535
    highL=cliphi/65535    
    deltaL=highL-lowL
    img-=lowL
    img/=deltaL
    return img

def applyLuminance():
    global ccModel
    if vars.L_tone!=0.5:   
        lum.calc(1-vars.L_tone)
        tonemap(lum,L_channel,ccModel)
    
    ccModel[:,:,L_channel]=applyClip(vars.L_lo,vars.L_hi,ccModel[:,:,L_channel])

def rebuildRGB():
    global out_image

    if Cmodel=='HSV':
       out_image = cv2.cvtColor(ccModel, cv2.COLOR_HSV2BGR)
    
    if Cmodel=='HLS':
       out_image = cv2.cvtColor(ccModel, cv2.COLOR_HLS2BGR)
    
    if Cmodel=='OKlab':
       #OKlab2RGB();
       oklab_to_linear_srgb(ccModel)

def RGBTones():
    global out_image

    out_image[:,:,2]=applyClip(vars.R_lo,vars.R_hi,out_image[:,:,2])
    out_image[:,:,1]=applyClip(vars.G_lo,vars.G_hi,out_image[:,:,1])
    out_image[:,:,0]=applyClip(vars.B_lo,vars.B_hi,out_image[:,:,0])
    
    if vars.R_tone!=0.5:   
        redtone.calc(1-vars.R_tone)
        tonemap(redtone,2,out_image)
    if vars.G_tone!=0.5:   
        greentone.calc(1-vars.G_tone)
        tonemap(greentone,1,out_image)
    if vars.B_tone!=0.5:   
        bluetone.calc(1-vars.B_tone)
        tonemap(bluetone,0,out_image)
        
def RGBweight_shift():
    global out_image
    out_image[:,:,0]=out_image[:,:,0]*vars.B_weight+vars.B_shift/100
    out_image[:,:,1]=out_image[:,:,1]*vars.G_weight+vars.G_shift/100
    out_image[:,:,2]=out_image[:,:,2]*vars.R_weight+vars.R_shift/100
            

#RGB CONVOLVE   
def RGBsharpen():
   
    global base, out_image,disp_image
     
    if vars.filterchange:
        if Blurmode==Blurs[0]:
           GaussBlur(base)
        if Blurmode==Blurs[1]:
           BilatBlur(base)
        
    
    out_image=Sharpen()

    RGBTones()
    out_image=np.clip(out_image,0,1)
        
    out_image*=65535
    disp_image=out_image.astype('uint16') 
    
    

#LUMCONVOLVE       
def LUMsharpen():
    global ccBase, ccModel, out_image, disp_image, L_channel,  b_hist, r_hist, g_hist, l_hist
          
     #ccBase is the reference and uses an L_channel 
    if vars.filterchange:
        
        if Blurmode==Blurs[0]:
            GaussBlur(ccBase[:,:,L_channel])
   
        if Blurmode==Blurs[1]:
            BilatBlur(ccBase[:,:,L_channel])
      
      
    #create enhanced version based on blur3 as a base 
    ccModel[:,:,L_channel]=Sharpen()
    
    #Apply LUMINANCE
    applyLuminance();

     #Apply GAMMA on L channel
    applyGamma()
    
    #Apply SATURATION   
    applySaturation();
    
    rebuildRGB()
    
    #BGR arranged data
    RGBTones()

    RGBweight_shift();

    out_image=np.clip(out_image,0,1)
    #convert to 16bit RGB
    out_image *=65535

    disp_image=out_image.astype('uint16') 
     
    calcHistogram()

  

memimg_loaded=False
try:
  print(vars.difdimy)
  print(vars.difdimx)
  mem_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.uint16)  
  
  disp_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.uint16)  
  base=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  ccBase=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  ccModel=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  out_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  blur1=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  blur2=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  blur3=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  highpass1=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  highpass2=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  highpass3=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  b_hist=np.zeros(65535).astype(np.float32)
  g_hist=np.zeros(65535).astype(np.float32)
  r_hist=np.zeros(65535).astype(np.float32)
  l_hist=np.zeros(65535).astype(np.float32)
  
  vars.clipLo=0
  vars.clipHi=65535
  print('image initialized')
  print(mem_image.shape)
  print('sum',mem_image.sum())
  mem_image_loaded=True
  lum=ToneControl(name='lum',m=0.5)
  sat=ToneControl(name='sat',m=0.5)
  redtone=ToneControl(name='red',m=0.5)
  greentone=ToneControl(name='green',m=0.5)
  bluetone=ToneControl(name='blue',m=0.5)
 
except:
  print('image NOT initialized')


