import laz_vars as vars # type: ignore
from dataclasses import dataclass
import cProfile
import functools
import pstats

profiler = cProfile.Profile()
   

def profile(func):
    @functools.wraps(func)
    def inner(*args, **kwargs):
        profiler = cProfile.Profile()
        profiler.enable()
        try:
            retval = func(*args, **kwargs)
        finally:
            profiler.disable()
            with open('profile.out', 'w') as profile_file:
                stats = pstats.Stats(profiler, stream=profile_file)
                stats.print_stats()
        return retval

    return inner

#20240804  *******************************************************
import numpy as np # type: ignore
import cv2 # type: ignore

import time
@dataclass
class Gaussians:
    s1: float =0.1
    s2: float =0.1
    s3: float =0.1
    gaussC: float =2.35*np.sqrt(np.pi)
    kernel: int = 0
    
    def calc(self, gaussC):
        self.s1=vars.sigma1*gaussC #conversion between wavesharp and cv2 gaussian
        self.s2=vars.sigma2*gaussC #conversion between wavesharp and cv2 gaussian
        self.s3=vars.sigma3*gaussC #conversion between wavesharp and cv2 gaussian

    def __post_init__(self):
        self.calc(self.gaussC)
        #print(self)

@dataclass
class toneControl:
    name: str
    m: float =0.5
    m_1: float =0
    m2_1: float =0
    def calc(self, m):
        self.m=m
        self.m_1=self.m-1
        self.m2_1=2*self.m-1

    def map(self, channel, image, newm):
        self.calc(newm)
        image[:,:,channel]=(image[:,:,channel]*self.m_1)/(image[:,:,channel]*self.m2_1-self.m) 

    def __post_init__(self):
        self.calc(self.m)
        print(self)
 
verbose=False

redConversion=0.299
greenConversion=0.587
blueConversion=0.114

#blurring methods ********************************************************************  
def GaussBlur(img):
    global highpass1, highpass2, highpass3, blur3
    g=Gaussians()
    print(g)    
    useROI=False
    if useROI:
        section_X=slice(int(vars.proc_L),int(vars.proc_R))
        section_Y=slice(int(vars.proc_T),int(vars.proc_B))

        blur1=cv2.GaussianBlur(img[section_Y,section_X],(g.kernel, g.kernel),g.s1,)
        highpass1=cv2.subtract(img[section_Y,section_X],blur1)
        blur2=cv2.GaussianBlur(blur1,(g.kernel, g.kernel),g.s2 ,)
        highpass2=cv2.subtract(blur1,blur2)
        blur3=cv2.GaussianBlur(blur2,(g.kernel, g.kernel),g.s3 ,)
        highpass3=cv2.subtract(blur2,blur3)
    else:
        blur1=cv2.GaussianBlur(img,(g.kernel, g.kernel),g.s1,)#.astype('float32')
        highpass1=cv2.subtract(img,blur1)#.astype('float32')
        blur2=cv2.GaussianBlur(blur1,(g.kernel, g.kernel),g.s2 ,)#.astype('float32')
        highpass2=cv2.subtract(blur1,blur2)#.astype('float32')
        blur3=cv2.GaussianBlur(blur2,(g.kernel, g.kernel),g.s3 ,)#.astype('float32')
        highpass3=cv2.subtract(blur2,blur3)#.astype('float32')
    
    vars.filter_change=False    

    
def BilatBlur(img):
    global highpass1, highpass2, highpass3, blur3
    r=vars.Bilatr
    g=Gaussians()
    blur1=cv2.bilateralFilter(img,-1,g.s1 ,r).astype('float32')
    highpass1=cv2.subtract(img,blur1).astype('float32')
    blur2=cv2.bilateralFilter(blur1,-1,g.s2 ,r).astype('float32')
    highpass2=cv2.subtract(blur1,blur2).astype('float32')
    blur3=cv2.bilateralFilter(blur2,-1,g.s3 ,r).astype('float32')
    highpass3=cv2.subtract(blur2,blur3).astype('float32')  
    vars.filter_change=False 


blurfunctions=[GaussBlur, GaussBlur, BilatBlur]

#end blurring **************************************************************************

#color conversions *********************************************************************

def rgb2HLS(base):
    global ccBase,ccModel
    L_channel=1
    ccBase = cv2.cvtColor(base, cv2.COLOR_BGR2HLS)
    ccBase[:,:,L_channel]=base[:,:,0]*redConversion+base[:,:,1]*greenConversion+base[:,:,2]*blueConversion
    ccModel=ccBase.copy()

def HLS2rgb(img):
    return cv2.cvtColor(img, cv2.COLOR_HLS2BGR)


#************************    

def rgb2HSV(base):
    global ccBase,ccModel
    L_channel=2
    ccBase = cv2.cvtColor(base, cv2.COLOR_BGR2HSV)
    ccBase[:,:,L_channel]=base[:,:,0]*redConversion+base[:,:,1]*greenConversion+base[:,:,2]*blueConversion
    ccModel=ccBase.copy()

def HSV2rgb(img):
    return cv2.cvtColor(img, cv2.COLOR_HSV2BGR)
   
#************************
def linear_srgb_to_oklab(c):
    global ccModel, ccBase
    c=np.clip(c,0,1)
    # print('okB ', c[:,:,0].sum()*65535)
    # print('okG ', c[:,:,1].sum()*65535)
    # print('okR ', c[:,:,2].sum()*65535) 
    
    l=  0.4122214708 * c[:,:,2] + 0.5363325363 * c[:,:,1] + 0.0514459929 * c[:,:,0]
    m=  0.2119034982 * c[:,:,2] + 0.6806995451 * c[:,:,1] + 0.1073969566 * c[:,:,0]
    s=  0.0883024619 * c[:,:,2] + 0.2817188376 * c[:,:,1] + 0.6299787005 * c[:,:,0]

    l_ = l**(1./3.)
    m_ = m**(1./3.)
    s_ = s**(1./3.)
      
    okL=	0.2104542553*l_ + 0.7936177850*m_ - 0.0040720468*s_
    oka=	1.9779984951*l_ - 2.4285922050*m_ + 0.4505937099*s_
    okb=	0.0259040371*l_ + 0.7827717662*m_ - 0.8086757660*s_
     
    ccModel[:,:,0]=np.power(okL,2.4)

    ccModel[:,:,1]=oka
    ccModel[:,:,2]=okb

    # print(oka.dtype)

    # print('okl',okL.sum())
    # print('okl',ccModel[:,:,0].sum()*65535)
    
    # print('oka',oka.sum())
    # print('okb',okb.sum())
    
    ccBase=ccModel.copy()

def oklab_to_linear_srgb(c):
    
    c[:,:,0]=np.power(c[:,:,0],1/2.4) 
    c[:,:,0]=np.clip(c[:,:,0],0,1)
    
    # print('okL ', c[:,:,0].sum())
    # print('oka ', c[:,:,1].sum())
    # print('okb ', c[:,:,2].sum()) 

    l_ = c[:,:,0] + 0.3963377774 * c[:,:,1] + 0.2158037573 * c[:,:,2]
    m_ = c[:,:,0] - 0.1055613458 * c[:,:,1] - 0.0638541728 * c[:,:,2]
    s_ = c[:,:,0] - 0.0894841775 * c[:,:,1] - 1.2914855480 * c[:,:,2]

    l = l_*l_*l_
    m = m_*m_*m_
    s = s_*s_*s_
    
    rgb=c.copy()
    rgb[:,:,2]=+4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    rgb[:,:,1]=-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    rgb[:,:,0]=-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s    

    rgb=np.clip(rgb,0,1)

    return rgb
# ok_gamma=2.4

# def linear_srgb_to_oklab(c):
#     global ccModel, ccBase
#     #c=np.clip(c,0,1)
    
#     l = 0.4121656120 * c[:,:,2] + 0.5362752080 * c[:,:,1] + 0.0514575653 * c[:,:,0]
#     m = 0.2118591070 * c[:,:,2] + 0.6807189584 * c[:,:,1] + 0.1074065790 * c[:,:,0]
#     s = 0.0883097947 * c[:,:,2] + 0.2818474174 * c[:,:,1] + 0.6302613616 * c[:,:,0]

#     l = np.cbrt(l)
#     m = np.cbrt(m)
#     s = np.cbrt(s)

#     okL=	np.power(0.2104542553*l + 0.7936177850*m - 0.0040720468*s, ok_gamma)
#     oka=	1.9779984951*l - 2.4285922050*m + 0.4505937099*s
#     okb=	0.0259040371*l + 0.7827717662*m - 0.8086757660*s

#     ccBase= np.dstack((okL,oka,okb))
#     ccModel=ccBase.copy()
    
# def oklab_to_linear_srgb(c):

#     #c[:,:,0]=np.clip(c[:,:,0],0,1) #prevent negative values in np.power 1/2.4 
#     c[:,:,0]=np.power(c[:,:,0],1/ok_gamma) #convert Luminance back to original non-linear shape

#     outrgb=np.zeros(c.shape)
#     l_ = c[:,:,0] + 0.3963377774 * c[:,:,1] + 0.2158037573 * c[:,:,2]
#     m_ = c[:,:,0] - 0.1055613458 * c[:,:,1] - 0.0638541728 * c[:,:,2]
#     s_ = c[:,:,0] - 0.0894841775 * c[:,:,1] - 1.2914855480 * c[:,:,2]

#     l = l_*l_*l_
#     m = m_*m_*m_
#     s = s_*s_*s_

#     outrgb[:,:,2]=	+ 4.0767245293*l - 3.3072168827*m + 0.2307590544*s
#     outrgb[:,:,1]=	- 1.2681437731*l + 2.6093323231*m - 0.3411344290*s
#     outrgb[:,:,0]=	- 0.0041119885*l - 0.7034763098*m + 1.7068625689*s

#     return outrgb

#************************

fromRGBfunc=[rgb2HSV,rgb2HLS,linear_srgb_to_oklab]

toRGBfunc=[HSV2rgb,HLS2rgb,oklab_to_linear_srgb]

def rebuildRGB():
    global out_image, ccModel, l_hist
    out_image=toRGBfunc[cModel.toRGB_idx](ccModel)

@dataclass
class colorModel:
    name:str ='HLS'
    L:int =1
    S:int =2
    fromRGB_idx:int= 0
    toRGB_idx: int=0

hsl=colorModel('HLS',L=1,S=2,fromRGB_idx=1, toRGB_idx=1)
hsv=colorModel('HSV',L=2,S=1,fromRGB_idx=0, toRGB_idx=0)
oklab = colorModel('OKlab',L=0,S=1,fromRGB_idx=2, toRGB_idx=2)

cmodels=[hsv,hsl,oklab]

cModel=oklab #startup model
#************************
    
#################################################################################################
def setBase():

      global cModel, mem_image,base, ccBase, L_channel, S_channel, ccModel
      base=mem_image.astype('float32')
    #   print('B ', mem_image[:,:,0].sum()*65535)
    #   print('G ', mem_image[:,:,1].sum()*65535)
    #   print('R ', mem_image[:,:,2].sum()*65535)
    #   print('B ', base[:,:,0].sum()*65535)
    #   print('G ', base[:,:,1].sum()*65535)
    #   print('R ', base[:,:,2].sum()*65535)
       
      vars.clipLo=base.min()
      vars.clipHi=base.max()
      
      #conversion to 0..1 range    
      if base.max()>512: #check for 16bit data
         base=base/65535
      else:
          base=base/255   

      fromRGBfunc[cModel.fromRGB_idx](base)

      L_channel=cModel.L
      S_channel=cModel.S
      #print(cModel)
   

def calcHistogram():
    global  b_hist, r_hist, g_hist, l_hist
    #BGR
    b_hist = cv2.calcHist([disp_image], [0], None, [65535], [0,65535])
    g_hist = cv2.calcHist([disp_image], [1], None, [65535], [0,65535])
    r_hist = cv2.calcHist([disp_image], [2], None, [65535], [0,65535])

    tmp=disp_image.copy()
    tmp[:,:,0]=+disp_image[:,:,0]*redConversion+disp_image[:,:,1]*greenConversion+disp_image[:,:,2]*blueConversion  
    l_hist = cv2.calcHist([tmp], [0], None, [65535], [0,65535])
                                     
        

def Sharpen():
    useROI=False
    if useROI:
        section_X=slice(int(vars.proc_L),int(vars.proc_R))
        section_Y=slice(int(vars.proc_T),int(vars.proc_B))
        img = np.zeros(base.shape)
        img[section_Y,section_X] = blur3.copy()
        if vars.layer1==True:
            img[section_Y,section_X]+=highpass1*vars.sharpen1
        if vars.layer2==True:
            img[section_Y,section_X]+=highpass2*vars.sharpen2
        if vars.layer3==True:
            img[section_Y,section_X]+=highpass3*vars.sharpen3
    else:
        img = blur3.copy()
        if vars.layer1==True:
            img+=highpass1*vars.sharpen1
        if vars.layer2==True:
            img+=highpass2*vars.sharpen2
        if vars.layer3==True:
            img+=highpass3*vars.sharpen3        

    return img  

def stretchImg(cliplo, cliphi,img):
    lowL=cliplo/65535
    highL=cliphi/65535    
    deltaL=highL-lowL
    if deltaL==0:
        deltaL=1
    img-=lowL
    img/=deltaL

    return img

def applyGamma():
     global ccModel,L_channel
     ccModel[:,:,L_channel]= np.power(ccModel[:,:,L_channel],1/vars.Gamma)    


def applySaturation():
    global ccModel, ccBase, S_channel
    if vars.S_tone!=0.5:   
        #sat.calc(1-vars.S_tone)
        #copy original S channel and enhance
        ccModel[:,:,S_channel]=ccBase[:,:,S_channel] #HLS and OKlab use S=2
        sat.map(S_channel,ccModel,newm=1-vars.S_tone)
        #ccModel[:,:,S_channel]=np.clip(ccModel[:,:,S_channel],0,1)
        if cModel.name=='OKlab':  #in OKLab also tone channel 1
           ccModel[:,:,2]=ccBase[:,:,2]
           sat.map(2,ccModel,newm=1-vars.S_tone)
           #ccModel[:,:,1]=np.clip(ccModel[:,:,1],0,1)
 
  
def applyLuminance():
    global ccModel, L_channel
    lum.map(L_channel,ccModel,newm=1-vars.L_tone)
    ccModel[:,:,L_channel]=stretchImg(vars.L_lo,vars.L_hi,ccModel[:,:,L_channel])
    

def RGBTones():
    global out_image
    if (vars.R_tone!=0.5) | (vars.G_tone!=0.5) | (vars.B_tone!=0.5) :
        out_image[:,:,2]=stretchImg(vars.R_lo,vars.R_hi,out_image[:,:,2])
        out_image[:,:,1]=stretchImg(vars.G_lo,vars.G_hi,out_image[:,:,1])
        out_image[:,:,0]=stretchImg(vars.B_lo,vars.B_hi,out_image[:,:,0])
        
    if vars.R_tone!=0.5:   
        #redtone.calc(1-vars.R_tone)
        redtone.map(2,out_image,newm=1-vars.R_tone)
    if vars.G_tone!=0.5:   
        #greentone.calc(1-vars.G_tone)
        greentone.map(1,out_image,newm=1-vars.G_tone)
    if vars.B_tone!=0.5:   
        #bluetone.calc(1-vars.B_tone)
        bluetone.map(0,out_image,newm=1-vars.B_tone)
    
def RGBweight_shift():
    global out_image
    #if weights are used
    if (vars.R_weight!=1.0) | (vars.G_weight!=1.0) | (vars.B_weight!=1.0) :
        out_image[:,:,0]=out_image[:,:,0]*vars.B_weight
        out_image[:,:,1]=out_image[:,:,1]*vars.G_weight
        out_image[:,:,2]=out_image[:,:,2]*vars.R_weight
    #if shifts are used    
    if  (vars.R_shift!=0.0) | (vars.G_shift!=0.0) | (vars.B_shift!=0.0) :
        out_image[:,:,0]=out_image[:,:,0]+vars.B_shift/100
        out_image[:,:,1]=out_image[:,:,1]+vars.G_shift/100
        out_image[:,:,2]=out_image[:,:,2]+vars.R_shift/100
        
                
#*********************************************************************************************************************************
def Convolve(style):
    global sectionX, sectionY, cModel, blur_func, ccBase, ccModel, out_image, disp_image, L_channel, S_channel, b_hist, r_hist, g_hist, l_hist
    #if any of the top level settings changes the filter should be updated

    #sectionY=slice(int(vars.proc_L),int(vars.proc_R))
    #sectionX=slice(int(vars.proc_T),int(vars.proc_B))
    #print('slice' ,sectionY)   

    if vars.ccmodel_change:
        print('ccModelchange')
        cModel=cmodels[vars.Cmode]
        setBase()
        vars.filter_change=True

    if vars.Convolve_change:
        print('convolvechange')
        setBase()
        print(style)
        vars.filter_change=True

    if vars.filterModel_change:
        print('filterchange')
        blur_func=blurfunctions[vars.filterModel]
        vars.filter_change=True

    #RGB*******************************************************         
    if style=='RGB':
      if vars.filter_change:
        blur_func(base)
       
      ccModel=Sharpen()

      #limit vars to 0..1 range before casting  into model
      ccModel=np.clip(ccModel,0,1)
      fromRGBfunc[cModel.fromRGB_idx](ccModel)
      L_channel=cModel.L
      S_channel=cModel.S

    #LUM*******************************************************
    if style=='LUM':
        #update blur/highpass 
        if vars.filter_change:
            blur_func(ccBase[:,:,L_channel])    
                
        #create enhanced version based on blur3 as a base 
        ccModel[:,:,L_channel]=Sharpen()
    
    
    #Apply LUMINANCE GAMMA SATURATION **************************
    if (vars.L_tone!=0.5) |(vars.L_lo!=0) | (vars.L_hi!=65535):   
        applyLuminance()
        
      #Apply GAMMA on L channel
    if vars.Gamma!=1:
        applyGamma()
    
    vars.clipHi=ccModel[:,:,L_channel].max()*65535
    vars.clipLo=ccModel[:,:,L_channel].min()*65535
    
    #Apply SATURATION
    if vars.S_tone!=0.5:    
        applySaturation();
    
    #reconstruct from L + other channels ************************
    rebuildRGB()
  
    RGBTones()
    
    RGBweight_shift();
    
    out_image=np.clip(out_image,0,1)
        
    out_image*=65535
    disp_image=out_image.astype('uint16') 
    
    calcHistogram()
    
 

memimg_loaded=False
try:
    print(vars.difdimy)
    print(vars.difdimx)
    #original image
    mem_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.uint16)
    #output images  
    disp_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.uint16)  
    out_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)

    #storage for blurring routines
    base=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
    ccBase=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
    ccModel=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
    blur_func=blurfunctions[0]
    #blurf_idx=0 

    #main storage for sharpener 
    blur3=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
    highpass1=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
    highpass2=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
    highpass3=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
    #histogram storage
    b_hist=np.zeros(65535).astype(np.float32)
    g_hist=np.zeros(65535).astype(np.float32)
    r_hist=np.zeros(65535).astype(np.float32)
    l_hist=np.zeros(65535).astype(np.float32)
    #tone controls    
    lum=toneControl(name='lum',m=0.5)
    sat=toneControl(name='sat',m=0.5)
    redtone=toneControl(name='red',m=0.5)
    greentone=toneControl(name='green',m=0.5)
    bluetone=toneControl(name='blue',m=0.5)
     
    vars.clipLo=0
    vars.clipHi=65535

    print('image initialized')
    print(mem_image.shape)
    print('sum',mem_image.sum())
    mem_image_loaded=True
   

 
except:
  print('image NOT initialized')

#profiler.enable()

def profiler_end():
 #   profiler.disable()
 #   with open('profile.out', 'w') as profile_file:
 #           stats = pstats.Stats(profiler, stream=profile_file).sort_stats('cumtime')
 #           stats.print_stats()
 pass


