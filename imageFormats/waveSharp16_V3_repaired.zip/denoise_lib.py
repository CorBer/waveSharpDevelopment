import laz_vars as ws_vars
import numpy as np
import cv2
#from pprof import cpu

#create circular matrix with distance to center for radial profiles
#@cpu
def create_dist_from_center(data):
    center = (int(data.shape[1]/2), int(data.shape[0]/2))
    y,x = np.indices((data.shape)) # first determine radii of all pixels
    r = np.int32(np.sqrt((x-center[0])**2+(y-center[1])**2))
    circular_set=True
    print(circular_set)
    return r    


#calculate radial profile using dist_from_center matrix
#@cpu

def radial_profile(data,dist ):
    # radius of the image.
    r_max = np.max(dist)  
    radial_profile, radius = np.histogram(dist, weights=(data), bins=int(r_max))
    return np.log10((radial_profile)+1)

#@cpu
def create_circular_mask(dist):
      
    maxr=dist.max()+1
    
    #lut is the profile, lutbase creates the lut array with maxr positions in steps of maxr/100
    s1= ws_vars.denoise_mid
    s2 = 1- s1
    sw= ws_vars.denoise_width 
    sc= ws_vars.denoise_curve/10
    idx=int(s1*maxr)
    lut_w=int(maxr*sw)  
    
   
    #step 1: set ones until the start of the filter
    lut=np.ones(idx).astype(np.float32)

    #create array with lut_w values in range 0..1
    lutbase = np.linspace(0, 1, lut_w).astype(np.float32) #use width to create the no of curve-bins
    # crate WS style logistic function for lutbase
    tlut=1-1/(1+np.exp(-sc-10*lutbase)).astype(np.float32)
    #normalize into to 0..1 range    
    tlut-=tlut.min()
    tlut/=tlut.max() 

    #add the curve section but limit to maxr
    lut=np.append(lut,tlut)
    lut=lut[:maxr]
    
    ws_vars.lut_end_idx = len(lut) #end of filtered section

    #fill the remainder of the array with zeros 
    if maxr>len(lut):
        tlut=np.zeros(maxr-len(lut))
        lut=np.append(lut,tlut)

    #convert to 32bit for transfer to pascal
    lut=lut.astype(np.float32)
       
    #set variables for pascal 
    ws_vars.lut_n=int(maxr)
    ws_vars.lut_start_idx = idx 

    lut_arr=np.copy(lut)
        
    #mask is created by using the indices from dist_from_center and the lut-profile
    mask=lut[dist]
    mask=np.fft.ifftshift(mask) 
    return mask, lut_arr

  

def crop_center(img,cropx,cropy):
    y,x,c = img.shape
    startx = x//2-(cropx//2)
    starty = y//2-(cropy//2)    
    return img[starty:starty+cropy,startx:startx+cropx,]

print('denoise.py loaded')