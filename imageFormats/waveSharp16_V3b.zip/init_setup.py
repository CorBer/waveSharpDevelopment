#init py sets defaults for global variables
#output images  
import laz_vars as ws_vars
import numpy as np
import sys


disp_image=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.uint16)  
#graph for denoise
graph_image=np.zeros((400,800,3)).astype(np.uint16)
#processed outputimage
out_image=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)

 #storage for blurring routines
#original RGB
base=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
#original as colourmodel
ccBase=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
#active colourmodel
ccModel=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)

blur3=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
#differential layers
highpass1=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
highpass2=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
highpass3=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)

nbins=1000
b_hist=np.zeros(nbins).astype(np.float32)
g_hist=np.zeros(nbins).astype(np.float32)
r_hist=np.zeros(nbins).astype(np.float32)
l_hist=np.zeros(nbins).astype(np.float32)

ws_vars.pythonVersion=str(sys.version).split(' (')[0].split('.')[1]


   
