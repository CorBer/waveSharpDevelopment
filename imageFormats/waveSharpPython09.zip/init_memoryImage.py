import laz_vars as ws_vars # type: ignore
from dataclasses import dataclass

#######################################################################################################
import cProfile
import functools
import pstats
import sys

#from numba import njit


def profile(func):
    @functools.wraps(func)
    def inner(*args, **kwargs):
        profiler = cProfile.Profile()
        profiler.enable()
        try:
            retval = func(*args, **kwargs)
        finally:
            profiler.disable()
            with open('profile.out', 'w') as profile_file:
                stats = pstats.Stats(profiler, stream=profile_file)
                stats.print_stats()
        return retval

    return inner

def start_profiler():
    global profiler
    try:
      profiler = cProfile.Profile()
      profiler.enable()
    except:
        pass  
    
def close_profiler():
    try:
        from datetime import datetime
        profiler.disable()
        timestr=datetime.now().strftime("%Y%m%d%H%M%S")
        with open('profile_'+timestr+'.out', 'w') as profile_file:
                stats = pstats.Stats(profiler, stream=profile_file).sort_stats('cumtime')
                stats.print_stats()   
    except:
        pass

#20240804  *******************************************************
import numpy as np # type: ignore
import cv2 # type: ignore

import time
@dataclass(slots=True)
class Gaussians:
    s1: float =0.1
    s2: float =0.1
    s3: float =0.1
    gaussC: float =2.35*np.sqrt(np.pi)
    kernel: int = 0
    
    def calc(self, gaussC):
        self.s1=ws_vars.sigma1*gaussC #conversion between wavesharp and cv2 gaussian
        self.s2=ws_vars.sigma2*gaussC #conversion between wavesharp and cv2 gaussian
        self.s3=ws_vars.sigma3*gaussC #conversion between wavesharp and cv2 gaussian

    def __post_init__(self):
        self.calc(self.gaussC)
        #print(self)

@dataclass(slots=True)
class toneControl:
    name: str
    m: float =0.5
    m_1: float =0
    m2_1: float =0
    def calc(self, m):
        self.m=m
        self.m_1=self.m-1
        self.m2_1=2*self.m-1

    def mapTone(self, channel, image, newm):
        self.calc(newm)
        image[:,:,channel]=(image[:,:,channel]*self.m_1)/(image[:,:,channel]*self.m2_1-self.m) 
            
    def __post_init__(self):
        self.calc(self.m)
        print(self)
 
################################################################################################# 


#create circular matrix with distance to center to create radial profiles
def create_dist_from_center(data):
    center = (int(data.shape[1]/2), int(data.shape[0]/2))
    y,x = np.indices((data.shape)) # first determine radii of all pixels
    r = np.int32(np.sqrt((x-center[0])**2+(y-center[1])**2))
    circular_set=True
    return r    


def radial_profile(data,dist ):
    # center = (int(data.shape[1]/2), int(data.shape[0]/2))
    # y,x = np.indices((data.shape)) # first determine radii of all pixels
    # r = np.int32(np.sqrt((x-center[0])**2+(y-center[1])**2))    

    # radius of the image.
    r_max = np.max(dist)  
    radial_profile, radius = np.histogram(dist, weights=(data), bins=int(r_max))
    print('profile', radial_profile.max())
    return np.log10(np.square(radial_profile)+1)

def create_circular_mask(h, w, dist):
    global lut_arr
    # center = (int(w/2), int(h/2))
    # radius = min(center[0], center[1], w-center[0], h-center[1])
    # Y, X = np.ogrid[:h, :w]
    # dist_from_center = np.int32(np.sqrt((X - center[0])**2 + (Y-center[1])**2))

    maxr=dist.max()+1
    
    #lut is the profile, lutbase creates the lut array with maxr positions in steps of maxr/100
    s1= ws_vars.denoise_mid
    s2 = 1- s1
    sw= 1-ws_vars.denoise_width
    sc= ws_vars.denoise_curve/2

    lutbase = np.linspace(0, 1, maxr)
    lut=np.ones(maxr)
        
    # WS style
    tlut=1-1/(1+np.exp(-round(sc)-100*sw*lutbase))
        
    tlut-=tlut.min()
    tlut/=tlut.max() 
    idx=int(s1*maxr) #fill with 1 until midpoint 
    lut[idx:]=tlut[:maxr-idx] #fill remainder with filtercurve
   
    ws_vars.lut_n=int(maxr)
    lut_arr=np.copy(lut).astype('float32')
          
    #mask is created using the indices from dist_from_center and the lut-profile
    mask=lut[dist]

    return mask

   

def set_circular_mask(img,dist):
    global circular_set
    rows, cols = img.shape
    cmask=create_circular_mask(rows,cols,dist)
    cmask=np.fft.ifftshift(cmask) #set the mask ready for use
    circular_set=True
    return cmask 

def crop_center(img,cropx,cropy):
    y,x,c = img.shape
    startx = x//2-(cropx//2)
    starty = y//2-(cropy//2)    
    return img[starty:starty+cropy,startx:startx+cropx,]

def denoise(img, display_image):
    global cmask, circular_set, graph_image, fft_profile, fft2_profile, dist_from_center
    rows, cols = img.shape
    shapefactor = rows/cols  #ex: r= 100 c =200 >0.5*400=200 below 0 more cols so 
    #if (circular_set==False) | (ws_vars.ROI_change) | (ws_vars.ccmodel_change) | (ws_vars.filterModel_change):
    dist_from_center=create_dist_from_center(img)
    
    lum=img.mean()
    dft = cv2.dft(np.float32(img),flags = cv2.DFT_COMPLEX_OUTPUT)

    if display_image:    
        dft_shift = np.fft.fftshift(dft)
        magnitude_spectrum = (cv2.magnitude(dft_shift[:,:,0],dft_shift[:,:,1]))
        fft_profile=radial_profile(magnitude_spectrum, dist_from_center).astype('float32')

        ws_vars.fft_profile_n=len(fft_profile)

    #if update_circular:
    cmask=set_circular_mask(img,dist_from_center)

    #vars.lut_rad=int(lut_arr.shape[0])
    #profile=(radial_profile(mask0))
    lut_img = np.zeros(shape=(300,800,3), dtype=np.int16)
    
    dft[:,:,0]=dft[:,:,0]*cmask
    dft[:,:,1]=dft[:,:,1]*cmask

    if display_image:
        dft_shift = np.fft.fftshift(dft)
        magnitude_spectrum = (cv2.magnitude(dft_shift[:,:,0],dft_shift[:,:,1]))
        fft2_profile=radial_profile(magnitude_spectrum,dist_from_center).astype('float32')
        ws_vars.fft2_profile_n=len(fft2_profile)

        mag_img=np.zeros(shape=(400,400,3))
        magnitude_spectrum=cv2.resize(magnitude_spectrum,(400, 400))
        magnitude_spectrum=20*np.log10(magnitude_spectrum+1)
        cv2.normalize(src=magnitude_spectrum, dst=magnitude_spectrum, alpha=0.0, beta=1.0, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
        mag_img[:,:,1]=magnitude_spectrum

    #DENOISED IMAGE
    img_back = cv2.idft(dft, flags=cv2.DFT_SCALE | cv2.DFT_REAL_OUTPUT)
   
    #DIFFERENCE DISPLAY
    if display_image:
    
        deltaimg=(img-img_back)
        deltaimg=np.clip(deltaimg,-5,5)
        
        dif_img=np.zeros(shape=(deltaimg.shape[0],deltaimg.shape[1],3))
        dif_img[:,:,1]=np.clip(deltaimg,0,None) #values above
        dif_img[:,:,2]=-np.clip(deltaimg,None,0) #values below in red

        dif_img = 20*np.log(dif_img+1)
        
        #cropping is possible
        if (dif_img.shape[0]>400) & (dif_img.shape[1]>400):
            dif_img = crop_center(dif_img,400,400)
        else:
            dif_img=cv2.resize(dif_img, (400, 400))

        cv2.normalize(src=dif_img, dst=deltaimg, alpha=0.0, beta=1.0, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
    
        #dif_img=cv2.resize(dif_img, (400, 400))
        deltaimg=np.hstack((dif_img, (mag_img)))
        graph_image=(deltaimg*65535).astype('uint16')

    #cv2.imshow('delta',deltaimg) 
    #keep original average brightness
    newlum=lum/img_back.mean()

    return img_back*newlum



#color conversions *********************************************************************

def rgb2HLS(base):
    ccBase = cv2.cvtColor(base, cv2.COLOR_BGR2HLS)
    ccBase[:,:,1]= base[:,:,0]*redConversion+base[:,:,1]*greenConversion+base[:,:,2]*blueConversion
    return ccBase
    
def HLS2rgb(img):
    return cv2.cvtColor(img, cv2.COLOR_HLS2BGR)

#************************    

def rgb2HSV(base): 
    ccBase = cv2.cvtColor(base, cv2.COLOR_BGR2HSV)
    ccBase[:,:,2]=base[:,:,0]*redConversion+base[:,:,1]*greenConversion+base[:,:,2]*blueConversion
    return ccBase

def HSV2rgb(img):
    return cv2.cvtColor(img, cv2.COLOR_HSV2BGR)
   
#************************

def linear_srgb_to_oklab(c):
       
    l=  0.4122214708 * c[:,:,2] + 0.5363325363 * c[:,:,1] + 0.0514459929 * c[:,:,0]
    m=  0.2119034982 * c[:,:,2] + 0.6806995451 * c[:,:,1] + 0.1073969566 * c[:,:,0]
    s=  0.0883024619 * c[:,:,2] + 0.2817188376 * c[:,:,1] + 0.6299787005 * c[:,:,0]

    l_ = l**(1./3.)
    m_ = m**(1./3.)
    s_ = s**(1./3.)
      
    okL=	0.2104542553*l_ + 0.7936177850*m_ - 0.0040720468*s_
    oka=	1.9779984951*l_ - 2.4285922050*m_ + 0.4505937099*s_
    okb=	0.0259040371*l_ + 0.7827717662*m_ - 0.8086757660*s_

    outmodel=np.zeros_like(c)
    outmodel[:,:,0]=np.power(okL,2.4)
    outmodel[:,:,1]=oka
    outmodel[:,:,2]=okb

    return outmodel

#@njit(parallel=True)
def oklab_to_linear_srgb(c):
    
    c[:,:,0]=np.clip(c[:,:,0],0,1)

    c[:,:,0]=np.power(c[:,:,0],1/2.4) 
    
    l_ = c[:,:,0] + 0.3963377774 * c[:,:,1] + 0.2158037573 * c[:,:,2]
    m_ = c[:,:,0] - 0.1055613458 * c[:,:,1] - 0.0638541728 * c[:,:,2]
    s_ = c[:,:,0] - 0.0894841775 * c[:,:,1] - 1.2914855480 * c[:,:,2]

    l = l_*l_*l_
    m = m_*m_*m_
    s = s_*s_*s_

    rgb=np.zeros_like(c)
    rgb[:,:,2]=+4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    rgb[:,:,1]=-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    rgb[:,:,0]=-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s    

    return rgb

fromRGBfunc=[rgb2HSV,rgb2HLS,linear_srgb_to_oklab]

toRGBfunc=[HSV2rgb,HLS2rgb,oklab_to_linear_srgb]
#************************

def convertRGB(img):
     return fromRGBfunc[cModel.toRGB_idx](img)

def rebuildRGB(img):
     return toRGBfunc[cModel.toRGB_idx](img)

@dataclass
class colorModel:
    name:str ='HLS'
    L:int =1
    S:int =2
    fromRGB_idx:int= 0
    toRGB_idx: int=0

hsv=colorModel('HSV',L=2,S=1,fromRGB_idx=0, toRGB_idx=0)       
hsl=colorModel('HLS',L=1,S=2,fromRGB_idx=1, toRGB_idx=1)
oklab = colorModel('OKlab',L=0,S=1,fromRGB_idx=2, toRGB_idx=2)

cmodels=[hsv,hsl,oklab]

cModel=oklab #startup model
#************************
    
#################################################################################################
def setBase():

      global cmask, cModel, mem_image,base, ccBase, L_channel, S_channel, ccModel, dist_from_center
      base=mem_image.astype('float32')
      print(cModel)
      ws_vars.clipLo=base.min()
      ws_vars.clipHi=base.max()
      
     
          
      #conversion to 0..1 range    
      if base.max()>512: #check for 16bit data
         base=base/65535
      else:
          base=base/255   

      #split RGB into L and 2 other (HS or ab) 
      ccBase= convertRGB(base)
      
      ccModel=np.copy(ccBase)

      L_channel=cModel.L
      S_channel=cModel.S
      try:
        cmask=set_circular_mask(base[:,:,0])
      except:
        pass   
      #print(cModel)
   

def calcHistogram(img):
    global  b_hist, r_hist, g_hist, l_hist
    nbins=1000
    #BGR
    b_hist = cv2.calcHist([img], [0], None, [nbins], [0,65535])
    g_hist = cv2.calcHist([img], [1], None, [nbins], [0,65535])
    r_hist = cv2.calcHist([img], [2], None, [nbins], [0,65535])
    
    #create L proxy
    tmp=np.zeros_like(img)
    tmp[:,:,0]=+img[:,:,0]*redConversion+img[:,:,1]*greenConversion+img[:,:,2]*blueConversion  
    l_hist = cv2.calcHist([tmp], [0], None, [nbins], [0,65535])
                                            
        

def Sharpen():
    img = np.copy(blur3)
    if ws_vars.layer1==True:
        img+=highpass1*ws_vars.sharpen1
    if ws_vars.layer2==True:
        img+=highpass2*ws_vars.sharpen2
    if ws_vars.layer3==True:
        img+=highpass3*ws_vars.sharpen3        

    return img  


def stretchImg(cliplo, cliphi,img):
    
    lowL=cliplo/65535
    highL=cliphi/65535    
    if (lowL!=0) or (highL!=1):
        deltaL=highL-lowL
        if deltaL==0:
            deltaL=1
        img-=lowL
        img/=deltaL

    return img

def applyGamma(img,L_channel):
     img[:,:,L_channel]= np.clip(img[:,:,L_channel],0,None)
     img[:,:,L_channel]= np.power(img[:,:,L_channel],1/ws_vars.Gamma)    


#uses ccBase to recalculate saturations needs the ROI info to copy from ccBase
def applySaturationV2(img,S_channel, section_X, section_Y):
    global ccBase
    img[:,:,S_channel]=ccBase[section_Y,section_X, S_channel] #OKlab use S=1
    sat.mapTone(S_channel,img,newm=1-ws_vars.S_tone)
    if cModel.name=='OKlab':  #in OKLab also tone channel 1
        img[:,:,2]=ccBase[section_Y,section_X,2] #OKlab uses S=1 default so S=2 
        sat.mapTone(2,img,newm=1-ws_vars.S_tone)

     
def applyLuminanceV1(img, l_channel):
    lum.mapTone(l_channel,img,newm=1-ws_vars.L_tone)
    img[:,:,l_channel]=stretchImg(ws_vars.L_lo,ws_vars.L_hi,img[:,:,l_channel])


def RGBTones(img):
    
    img[:,:,2]=stretchImg(ws_vars.R_lo,ws_vars.R_hi,img[:,:,2])
    img[:,:,1]=stretchImg(ws_vars.G_lo,ws_vars.G_hi,img[:,:,1])
    img[:,:,0]=stretchImg(ws_vars.B_lo,ws_vars.B_hi,img[:,:,0])
    
    if ws_vars.R_tone!=0.5:   
        redtone.mapTone(2,img,newm=1-ws_vars.R_tone)
    if ws_vars.G_tone!=0.5:   
        greentone.mapTone(1,img,newm=1-ws_vars.G_tone)
    if ws_vars.B_tone!=0.5:   
        bluetone.mapTone(0,img,newm=1-ws_vars.B_tone)
    return img

def RGBweight_shift(img):
    #if weights are used
    if (ws_vars.R_weight!=1.0) | (ws_vars.G_weight!=1.0) | (ws_vars.B_weight!=1.0) :
        img[:,:,0]=img[:,:,0]*ws_vars.B_weight
        img[:,:,1]=img[:,:,1]*ws_vars.G_weight
        img[:,:,2]=img[:,:,2]*ws_vars.R_weight
    #if shifts are used    
    if  (ws_vars.R_shift!=0.0) | (ws_vars.G_shift!=0.0) | (ws_vars.B_shift!=0.0) :
        img[:,:,0]=img[:,:,0]+ws_vars.B_shift/100
        img[:,:,1]=img[:,:,1]+ws_vars.G_shift/100
        img[:,:,2]=img[:,:,2]+ws_vars.R_shift/100
    return img    
                

#blurring methods ********************************************************************  
def GaussBlur(img):
    global highpass1, highpass2, highpass3, blur3
    g=Gaussians()
    #print(g)    

    blur1=cv2.GaussianBlur(img,(g.kernel, g.kernel),g.s1,)#.astype('float32')
    highpass1=cv2.subtract(img,blur1)#.astype('float32')
    blur2=cv2.GaussianBlur(blur1,(g.kernel, g.kernel),g.s2 ,)#.astype('float32')
    highpass2=cv2.subtract(blur1,blur2)#.astype('float32')
    blur3=cv2.GaussianBlur(blur2,(g.kernel, g.kernel),g.s3 ,)#.astype('float32')
    highpass3=cv2.subtract(blur2,blur3)#.astype('float32')

    ws_vars.filter_change=False    

    
def BilatBlur(img):
    global highpass1, highpass2, highpass3, blur3
    r=ws_vars.Bilatr
    g=Gaussians()
    blur1=cv2.bilateralFilter(img,-1,g.s1 ,r).astype('float32')
    highpass1=cv2.subtract(img,blur1).astype('float32')
    blur2=cv2.bilateralFilter(blur1,-1,g.s2 ,r).astype('float32')
    highpass2=cv2.subtract(blur1,blur2).astype('float32')
    blur3=cv2.bilateralFilter(blur2,-1,g.s3 ,r).astype('float32')
    highpass3=cv2.subtract(blur2,blur3).astype('float32')  
    ws_vars.filter_change=False 
    


blurfunctions=[GaussBlur, GaussBlur, BilatBlur]

#end blurring **************************************************************************

#*********************************************************************************************************************************
def Convolve(style, update_display):
    global dist_from_center, sectionX, sectionY, cModel, blur_func, ccBase, ccModel, out_image, disp_image, L_channel, S_channel, b_hist, r_hist, g_hist, l_hist, storedResult
    #if any of the top level settings changes the filter should be updated
    callfrom = ws_vars.caller.decode('ascii')
    print(callfrom)
    
    if ws_vars.ROI_change:
        ws_vars.filter_change=True
        
    #print('slice' ,sectionY)   

    if ws_vars.ccmodel_change:
        print('ccModelchange')
        cModel=cmodels[ws_vars.Cmode]
        setBase()
        ws_vars.filter_change=True

    if ws_vars.Convolve_change:
        print('convolvechange')
        setBase()
        print(style)
        ws_vars.filter_change=True

    if ws_vars.filterModel_change:
        print('filterchange')
        blur_func=blurfunctions[ws_vars.filterModel]
        ws_vars.filter_change=True
    
    useROI=ws_vars.useROI

    if useROI:
        section_X=slice(int(ws_vars.proc_L),int(ws_vars.proc_R))
        section_Y=slice(int(ws_vars.proc_T),int(ws_vars.proc_B))
    else:
        section_X=slice(0,base.shape[1])
        section_Y=slice(0,base.shape[0])
    
    
    #RGB and LUM update and DENOISE if requested by generic call*******************************************************
    if callfrom=='generic':
        if style=='RGB': 
        #blur a section or the full image
        
            if ws_vars.filter_change:
                blur_func(base[section_Y,section_X,:])

            ccModel[section_Y,section_X,:]=Sharpen()

            #limit vars to 0..1 range before casting  into model
            ccModel[section_Y,section_X,:]=np.clip(ccModel[section_Y,section_X,:],0,1)
            ccModel[section_Y,section_X,:]=fromRGBfunc[cModel.fromRGB_idx](ccModel[section_Y,section_X,:])
            
            L_channel=cModel.L
            S_channel=cModel.S
            
    #vars.lumAvg=ccModel[section_Y,section_X,L_channel].mean()

        #LUM*******************************************************
        if style=='LUM':
            print('LUM')
            #blur a section or the full image
            if ws_vars.filter_change:
                blur_func(ccBase[section_Y,section_X,L_channel])    
                    
            #return the enhanced version based on blur3 as a base 
            ccModel[section_Y,section_X,L_channel]=Sharpen()
        
        #DENOISE FIRST 
        if ws_vars.denoise_used:
          print('Denoising')
          ccModel[section_Y,section_X,L_channel]=denoise(ccModel[section_Y,section_X,L_channel], update_display)
        
        print('create stored convoluted image ')
        storedResult=ccModel[section_Y,section_X,:].copy()

    else: #retrieve previous
       print('use stored convoluted image')
       ccModel[section_Y,section_X,:]=storedResult

    #imgSelection is based on a calculated or stored L channel
    imgSelection=ccModel[section_Y,section_X,:].copy()
    
    #Apply LUMINANCE GAMMA SATURATION **************************
    

    if (ws_vars.L_tone!=0.5) |(ws_vars.L_lo!=0) | (ws_vars.L_hi!=65535):   
            applyLuminanceV1(imgSelection,L_channel)    
        
      #Apply GAMMA on L channel #will CLIP any value below zero after sharpening !
    if ws_vars.Gamma!=1:
            applyGamma(imgSelection,L_channel)
    
    #report extremes back 
    ws_vars.clipHi=imgSelection[:,:,L_channel].max()*65535
    ws_vars.clipLo=imgSelection[:,:,L_channel].min()*65535

    #denoise section *******************************************
    

    
    #reconstruct from L + other channels ************************
    if ws_vars.colour_used:
        #Apply SATURATION
        if ws_vars.S_tone!=0.5:    
            applySaturationV2(imgSelection,S_channel,section_X,section_Y)
        imgSelection=rebuildRGB(imgSelection)
        imgSelection=RGBTones(imgSelection)
        out_image=RGBweight_shift(imgSelection)
    else:  
        out_image=imgSelection.copy()
        print(out_image.shape)
        out_image[:,:,0]=imgSelection[:,:,L_channel]
        out_image[:,:,1]=imgSelection[:,:,L_channel]
        out_image[:,:,2]=imgSelection[:,:,L_channel]
                
    out_image=np.clip(out_image,0,1)
        
    out_image*=65535

    if ws_vars.calcHisto:
        calcHistogram(out_image)

    if useROI:
       #use original as background and copy ROI onto that
       disp_image=(base*65535).astype('uint16')
       disp_image[section_Y,section_X,:]=out_image.astype('uint16')
    else:
       disp_image=out_image.astype('uint16')
            
    #for name ,values in vars(lvars).items():
    #    print(name,'=', values)
    
 

memimg_loaded=False
try:
    print(ws_vars.difdimy)
    print(ws_vars.difdimx)
    verbose=False

    redConversion=0.299
    greenConversion=0.587
    blueConversion=0.114

    #original image
    mem_image=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.uint16)
    #output images  
    disp_image=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.uint16)  
    graph_image=np.zeros((400,800,3)).astype(np.uint16)
    out_image=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)

    #storage for blurring routines
    base=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    ccBase=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    ccModel=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    blur_func=blurfunctions[0]
    #blurf_idx=0 

    #main storage for sharpener 
    blur3=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    highpass1=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    highpass2=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    highpass3=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    #histogram storage
    b_hist=np.zeros(65535).astype(np.float32)
    g_hist=np.zeros(65535).astype(np.float32)
    r_hist=np.zeros(65535).astype(np.float32)
    l_hist=np.zeros(65535).astype(np.float32)
    #tone controls    
    lum=toneControl(name='lum',m=0.5)
    sat=toneControl(name='sat',m=0.5)
    redtone=toneControl(name='red',m=0.5)
    greentone=toneControl(name='green',m=0.5)
    bluetone=toneControl(name='blue',m=0.5)
     
    ws_vars.clipLo=0
    ws_vars.clipHi=65535

    print('image initialized')
    print(mem_image.shape)
    print('sum',mem_image.sum())
    mem_image_loaded=True
    ws_vars.pythonVersion=str(sys.version).split(' (')[0]
    print(ws_vars.pythonVersion)
    circular_set=False
    
  

 
except:
  print('image NOT initialized')
  


