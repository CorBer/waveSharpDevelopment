import laz_vars as ws_vars # type: ignore
from dataclasses import dataclass

import numpy as np # type: ignore
import cv2 # type: ignore
import time


#######################################################################################################
import cProfile
import functools
import pstats
import sys
import os

print ('\n'.join(sys.path))
print('Original working directory:', os.getcwd())
sys.path.append(os.getcwd())

#from numba import njit

################################################################################################# 

def profile(func):
    @functools.wraps(func)
    def inner(*args, **kwargs):
        profiler = cProfile.Profile()
        profiler.enable()
        try:
            retval = func(*args, **kwargs)
        finally:
            profiler.disable()
            with open('profile.out', 'w') as profile_file:
                stats = pstats.Stats(profiler, stream=profile_file)
                stats.print_stats()
        return retval

    return inner

def start_profiler():
    global profiler
    try:
      profiler = cProfile.Profile()
      profiler.enable()
    except:
        pass  
    
def close_profiler():
    try:
        from datetime import datetime
        profiler.disable()
        timestr=datetime.now().strftime("%Y%m%d%H%M%S")
        with open('profile_'+timestr+'.out', 'w') as profile_file:
                stats = pstats.Stats(profiler, stream=profile_file).sort_stats('cumtime')
                stats.print_stats()   
    except:
        pass
################################################################################################# 

@dataclass(slots=True)
class Gaussians:
    s1: np.float32 =0.1
    s2: np.float32 =0.1
    s3: np.float32 =0.1
    gaussC: np.float32 =2.35*np.sqrt(np.pi)
    kernel: np.int32 = 0
    
    def calc(self, gaussC):
        self.s1=ws_vars.sigma1*gaussC #conversion between wavesharp and cv2 gaussian
        self.s2=ws_vars.sigma2*gaussC #conversion between wavesharp and cv2 gaussian
        self.s3=ws_vars.sigma3*gaussC #conversion between wavesharp and cv2 gaussian

    def __post_init__(self):
        self.calc(self.gaussC)
        #print(self)

@dataclass(slots=True)
class toneControl:
    name: str
    m: np.float32 =0.5
    m_1: np.float32 =0
    m2_1: np.float32 =0
    def calc(self, m):
        self.m=m
        self.m_1=self.m-1
        self.m2_1=2*self.m-1

    def mapTone(self, channel, image, newm):
        self.calc(newm)
        image[:,:,channel]=(image[:,:,channel]*self.m_1)/(image[:,:,channel]*self.m2_1-self.m) 
            
    def __post_init__(self):
        self.calc(self.m)
        print(self)
 
################################################################################################# 
from denoise_lib import *

def denoise_img(img):
    print('denoise')
    global dist_from_center, cmask,  graph_image, lut_arr, fft_profile, fft2_profile
    display_image=True #ws_vars.denoise_displayupdate
    # img=oimg.copy()
    rows, cols = img.shape

    #create mask based on function settings and dist_from_center matrix
    
    cmask, lut_arr=set_circular_mask(img, dist_from_center)
   
    lum=img.mean()
    #dft = cv2.dft(np.float32(img),flags = cv2.DFT_SCALE | cv2.DFT_COMPLEX_OUTPUT)
    dft = cv2.dft(np.float32(img),flags = cv2.DFT_COMPLEX_OUTPUT)
    
    if display_image:    
        dft_shift = np.fft.fftshift(dft)
        magnitude_spectrum = (cv2.magnitude(dft_shift[:,:,0],dft_shift[:,:,1]))
        print('mag',magnitude_spectrum.shape)
        print('dist',dist_from_center.shape)
        
        fft_profile=radial_profile(magnitude_spectrum, dist_from_center).astype('float32')
        ws_vars.fft_profile_n=len(fft_profile)
    
    #apply denoise mask
    dft[:,:,0]=dft[:,:,0]*cmask
    dft[:,:,1]=dft[:,:,1]*cmask

    if display_image:
        dft_shift = np.fft.fftshift(dft)
        magnitude_spectrum = (cv2.magnitude(dft_shift[:,:,0],dft_shift[:,:,1]))
        fft2_profile=radial_profile(magnitude_spectrum,dist_from_center).astype('float32')
        ws_vars.fft2_profile_n=len(fft2_profile)

        mag_img=np.zeros(shape=(400,400,3))
        # minr=min(magnitude_spectrum.shape)
        # hminr=minr//2
        # magnitude_spectrum=magnitude_spectrum[0:minr,0:minr]

        magnitude_spectrum=cv2.resize(magnitude_spectrum,(400, 400))
        magnitude_spectrum=20*np.log10(magnitude_spectrum+1)
        cv2.normalize(src=magnitude_spectrum, dst=magnitude_spectrum, alpha=0.0, beta=1.0, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
        mag_img[:,:,1]=magnitude_spectrum  #show in green

    #DENOISED IMAGE

    #img_back = cv2.idft(dft, flags= cv2.DFT_SCALE | cv2.DFT_REAL_OUTPUT)
    img_back = cv2.idft(dft, flags= cv2.DFT_COMPLEX_INPUT |  cv2.DFT_REAL_OUTPUT |   cv2.DFT_SCALE )
       #keep original average brightness after denoising
    newlum=lum/img_back.mean()
    img_back=img_back*newlum
    
    #DIFFERENCE DISPLAY
    if display_image:
    
        deltaimg=(img-img_back)
        #make colour difference image 
        dif_img=np.zeros(shape=(deltaimg.shape[0],deltaimg.shape[1],3))
        dif_img[:,:,1]=np.clip(deltaimg,0,None) #values above
        dif_img[:,:,2]=-np.clip(deltaimg,None,0) #values below in red

        dif_img = 20*np.log(dif_img+1)
        
        #cropping is possible
        if (dif_img.shape[0]>400) & (dif_img.shape[1]>400):
            dif_img = crop_center(dif_img,400,400)
        else: #at least one axis smaller than 400
            nimg = np.zeros((400,400,3))
            r=min(rows,400)
            c=min(cols,400)
            nimg[200-r//2:200-r//2+r,200-c//2:200-c//2+c]=dif_img[:min(400,rows),:min(400,cols)]
             
            #nimg[:min(rows,400),:min(cols,400)]=dif_img[:min(400,rows),:min(400,cols)]
            dif_img=nimg

        cv2.normalize(src=dif_img, dst=deltaimg, alpha=0.0, beta=1.0, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
    
        #dif_img=cv2.resize(dif_img, (400, 400))
        deltaimg=np.hstack((dif_img, (mag_img)))
        graph_image=(deltaimg*65535).astype('uint16')

    return img_back


################################################################################################# 
from colourmodels import *

hsv=colourModelSetup('HSV',L=2,S=1,fromRGB_idx=0, toRGB_idx=0)       
hsl=colourModelSetup('HLS',L=1,S=2,fromRGB_idx=1, toRGB_idx=1)
oklab = colourModelSetup('OKlab',L=0,S=1,fromRGB_idx=2, toRGB_idx=2)

colourModels=[hsv,hsl,oklab]

activeColourModel=oklab #startup model
    


################################################################################################# 
@dataclass
class ws_Img:
    img : np.ndarray
    ccBase: np.ndarray
    ccMode: np.ndarray
    blur3: np.ndarray
    hp1: np.ndarray
    hp2: np.ndarray
    hp3: np.ndarray
    
    clipLo: int=0
    clipHi: int=65535

    def __post_init__(self):
        base=self.img.astype('float32')
        self.clipLo=base.min()
        self.clipHi=base.max()

        if base.max()>512: #check for 16bit data
            base=base/65535
        else:
            base=base/255 
        self.ccBase=convertRGB(base,activeColourModel)
        self.ccModel=np.copy(self.ccBase)

def openFile():
    global cmask, base, ccBase, ccModel, activeColourModel 
    #create setup from mem_image
    base=mem_image.astype('float32')
    print(activeColourModel)
    ws_vars.clipLo=base.min()
    ws_vars.clipHi=base.max()
            
    #conversion to 0..1 range    
    if base.max()>512: #check for 16bit data
        base=base/65535
    else:
        base=base/255   

    activeColourModel=colourModels[ws_vars.Cmode]
    blur_func=blurfunctions[ws_vars.filterModel]
    
    #split RGB into L and 2 other (HS or ab) 
    ccBase= convertRGB(base,activeColourModel)
    #base for active calculations
    ccModel=np.copy(ccBase)
    
    try:
        cmask=set_circular_mask(base[:,:,0])
    except:
        pass   
    ws_vars.filter_change=True
    ws_vars.ROI_change=True
    
    
#################################################################################################
#adapt to changes in requested colourModel 
def setBase():

      global cmask, activeColourModel, base, ccBase, L_channel, S_channel, ccModel, dist_from_center
      base=mem_image.astype('float32')
      print(activeColourModel)
      ws_vars.clipLo=base.min()
      ws_vars.clipHi=base.max()
              
      #conversion to 0..1 range    
      if base.max()>512: #check for 16bit data
         base=base/65535
      else:
          base=base/255   

      #split RGB into L and 2 other (HS or ab) 
      ccBase= convertRGB(base,activeColourModel)
      #base for active calculations
      ccModel=np.copy(ccBase)
      
      L_channel=activeColourModel.L
      S_channel=activeColourModel.S
      try:
        cmask=set_circular_mask(base[:,:,0])
      except:
        pass   
        

def calcHistogram(img, nbins):
    global  b_hist, r_hist, g_hist, l_hist
    #BGR
    b_hist = cv2.calcHist([img], [0], None, [nbins], [0,65535])
    g_hist = cv2.calcHist([img], [1], None, [nbins], [0,65535])
    r_hist = cv2.calcHist([img], [2], None, [nbins], [0,65535])
    
    #create L proxy
    tmp=np.zeros_like(img)
    tmp[:,:,0]=+img[:,:,0]*redConversion+img[:,:,1]*greenConversion+img[:,:,2]*blueConversion  
    l_hist = cv2.calcHist([tmp], [0], None, [nbins], [0,65535])
                                            
        

def Sharpen():
    img = np.copy(blur3) #background
    if ws_vars.layer1==True:
        img+=highpass1*ws_vars.sharpen1
    if ws_vars.layer2==True:
        img+=highpass2*ws_vars.sharpen2
    if ws_vars.layer3==True:
        img+=highpass3*ws_vars.sharpen3        

    return img  


def stretchImg(cliplo, cliphi,img):
    lowL=cliplo/65535
    highL=cliphi/65535    
    if (lowL!=0) or (highL!=1):
        deltaL=highL-lowL
        if deltaL==0:
            deltaL=1
        img-=lowL
        img/=deltaL

    return img

def applyGamma(img,L_channel):
     img[:,:,L_channel]= np.clip(img[:,:,L_channel],0,None) #prevent values <0 to be used
     img[:,:,L_channel]= np.power(img[:,:,L_channel],1/ws_vars.Gamma)    


#uses ccBase to recalculate saturations needs the ROI info to copy from ccBase
def applySaturationV2(img,ccBase, S_channel, section_X, section_Y):
    img[:,:,S_channel]=ccBase[section_Y,section_X, S_channel] #OKlab use S=1
    sat.mapTone(S_channel,img,newm=1-ws_vars.S_tone)
    if activeColourModel.name=='OKlab':  #in OKLab also tone channel 1
        img[:,:,2]=ccBase[section_Y,section_X,2] #OKlab uses S=1 default so S=2 
        sat.mapTone(2,img,newm=1-ws_vars.S_tone)

     
def applyLuminanceV1(img, l_channel):
    lum.mapTone(l_channel,img,newm=1-ws_vars.L_tone)
    img[:,:,l_channel]=stretchImg(ws_vars.L_lo,ws_vars.L_hi,img[:,:,l_channel])


def RGBTones(img):
    img[:,:,2]=stretchImg(ws_vars.R_lo,ws_vars.R_hi,img[:,:,2])
    img[:,:,1]=stretchImg(ws_vars.G_lo,ws_vars.G_hi,img[:,:,1])
    img[:,:,0]=stretchImg(ws_vars.B_lo,ws_vars.B_hi,img[:,:,0])
    
    if ws_vars.R_tone!=0.5:   
        redtone.mapTone(2,img,newm=1-ws_vars.R_tone)
    if ws_vars.G_tone!=0.5:   
        greentone.mapTone(1,img,newm=1-ws_vars.G_tone)
    if ws_vars.B_tone!=0.5:   
        bluetone.mapTone(0,img,newm=1-ws_vars.B_tone)
    return img

def RGBweight_shift(img):
    #if weights are used
    if (ws_vars.R_weight!=1.0) | (ws_vars.G_weight!=1.0) | (ws_vars.B_weight!=1.0) :
        img[:,:,0]=img[:,:,0]*ws_vars.B_weight
        img[:,:,1]=img[:,:,1]*ws_vars.G_weight
        img[:,:,2]=img[:,:,2]*ws_vars.R_weight
    #if shifts are used    
    if  (ws_vars.R_shift!=0.0) | (ws_vars.G_shift!=0.0) | (ws_vars.B_shift!=0.0) :
        img[:,:,0]=img[:,:,0]+ws_vars.B_shift/100
        img[:,:,1]=img[:,:,1]+ws_vars.G_shift/100
        img[:,:,2]=img[:,:,2]+ws_vars.R_shift/100
    return img    
                

#blurring methods ********************************************************************  
def GaussBlur(img):
    global highpass1, highpass2, highpass3, blur3
    g=Gaussians()
    #print(g)    

    blur1=cv2.GaussianBlur(img,(g.kernel, g.kernel),g.s1,)#.astype('float32')
    highpass1=cv2.subtract(img,blur1)#.astype('float32')
    blur2=cv2.GaussianBlur(blur1,(g.kernel, g.kernel),g.s2 ,)#.astype('float32')
    highpass2=cv2.subtract(blur1,blur2)#.astype('float32')
    blur3=cv2.GaussianBlur(blur2,(g.kernel, g.kernel),g.s3 ,)#.astype('float32')
    highpass3=cv2.subtract(blur2,blur3)#.astype('float32')

    ws_vars.filter_change=False    

    
def BilatBlur(img):
    global highpass1, highpass2, highpass3, blur3
    r=ws_vars.Bilatr
    g=Gaussians()
    blur1=cv2.bilateralFilter(img,-1,g.s1 ,r).astype('float32')
    highpass1=cv2.subtract(img,blur1).astype('float32')
    blur2=cv2.bilateralFilter(blur1,-1,g.s2 ,r).astype('float32')
    highpass2=cv2.subtract(blur1,blur2).astype('float32')
    blur3=cv2.bilateralFilter(blur2,-1,g.s3 ,r).astype('float32')
    highpass3=cv2.subtract(blur2,blur3).astype('float32')  
    ws_vars.filter_change=False 
    
blurfunctions=[GaussBlur, GaussBlur, BilatBlur]

#end blurring **************************************************************************

def processChanges():
    global activeColourModel, blur_func
    
    if ws_vars.ROI_change:
        ws_vars.filter_change=True
        
    if ws_vars.ccmodel_change:
        print('ccModelchange')
        activeColourModel=colourModels[ws_vars.Cmode]
        setBase()
        ws_vars.filter_change=True

    if ws_vars.Convolve_change:
        print('convolvechange')
        setBase()
        ws_vars.filter_change=True

    if ws_vars.filterModel_change:
        print('filterchange')
        blur_func=blurfunctions[ws_vars.filterModel]
        ws_vars.filter_change=True
    


#*********************************************************************************************************************************
def Convolve():
    convolve_method= ws_vars.convolve_method

    global dist_from_center, odist_from_center, sectionX, sectionY, activeColourModel, blur_func, ccBase, ccModel, out_image, disp_image, b_hist, r_hist, g_hist, l_hist, storedResult
    #if any of the top level settings changes the filter should be updated
    print('convolve') 
    callfrom = ws_vars.caller.decode('ascii')
    print(callfrom)

    #see if models/filters have been changed
    processChanges()
    
    #set the section we are sharpening/denoising etc
    useROI=ws_vars.useROI

    section_X, section_Y,dist_from_center = set_img_sections(useROI, odist_from_center)
    
    L_channel=activeColourModel.L
    S_channel=activeColourModel.S
    #RGB and LUM update and DENOISE if requested by generic call*******************************************************
    if callfrom=='generic':
        if convolve_method==1: 
            if ws_vars.filter_change:
                blur_func(base[section_Y,section_X,:])

            ccModel[section_Y,section_X,:]=Sharpen()

            #limit vars to 0..1 range before casting  into model
            ccModel[section_Y,section_X,:]=np.clip(ccModel[section_Y,section_X,:],0,1)
            #create Luminance based version
            ccModel[section_Y,section_X,:]=fromRGBfunc[activeColourModel.fromRGB_idx](ccModel[section_Y,section_X,:])
            #set the channels for L and S
            L_channel=activeColourModel.L
            S_channel=activeColourModel.S
            
        #LUM*******************************************************
        if convolve_method==0:
            print('LUM')
            if ws_vars.filter_change:
                blur_func(ccBase[section_Y,section_X,L_channel])    
                    
            #return the enhanced version based on blur3 as a base 
            ccModel[section_Y,section_X,L_channel]=Sharpen()
        
        #DENOISE *********************************** 
        if ws_vars.denoise_used:
               ccModel[section_Y,section_X,L_channel]=denoise_img(ccModel[section_Y,section_X,L_channel])
        
        storedResult=ccModel[section_Y,section_X,:].copy()

    else: #retrieve previously created version (sharpened and denoised)
        ccModel[section_Y,section_X,:]=storedResult

    ##################################################################################################
    
    #imgSelection is based on a freshly calculated or previously stored sharpened/denoised L channel
    imgSelection=ccModel[section_Y,section_X,:].copy()
    
    #Apply LUMINANCE GAMMA SATURATION **************************
    
    #if Luminance or the clips are set process with
    if (ws_vars.L_tone!=0.5) |(ws_vars.L_lo!=0) | (ws_vars.L_hi!=65535):   
            applyLuminanceV1(imgSelection,L_channel)    
        
      #Apply GAMMA on L channel #will CLIP any value below zero after sharpening !
    if ws_vars.Gamma!=1:
            applyGamma(imgSelection,L_channel)
    
    #report extremes back 
    ws_vars.clipHi=imgSelection[:,:,L_channel].max()*65535
    ws_vars.clipLo=imgSelection[:,:,L_channel].min()*65535

      
    #Apply Saturation(if requested) and reconstruct from L + other channels ************************
    if ws_vars.colour_used:
        #Apply SATURATION
        if ws_vars.S_tone!=0.5:    
            applySaturationV2(imgSelection,ccBase, S_channel,section_X,section_Y)

        imgSelection=rebuildRGB(imgSelection,activeColourModel)
        #apply R G B tones
        imgSelection=RGBTones(imgSelection)
        #apply R G B weights/shifts

        out_image=RGBweight_shift(imgSelection)

    else:  #BW image is a 3x copy of the L channel
        out_image=imgSelection.copy()
        print(out_image.shape)
        out_image[:,:,0]=imgSelection[:,:,L_channel]
        out_image[:,:,1]=imgSelection[:,:,L_channel]
        out_image[:,:,2]=imgSelection[:,:,L_channel]

    #this is the 32bit floating output image             
    out_image=np.clip(out_image,0,1)
    out_image*=65535
     
    #create a histogram if histogram is visible 
    if ws_vars.calcHisto:
        calcHistogram(out_image, nbins)
    
    #create the image to display
    if useROI:
       #use original as background and copy ROI onto that
       disp_image=(base*65535).astype('uint16')
       disp_image[section_Y,section_X,:]=out_image.astype('uint16')
    else:
       disp_image=out_image.astype('uint16')

def set_img_sections(useROI, odist_from_center):

    if useROI: #based on ROI set on screen by user
        #ROI needs to be an even-numbered setup to allow proper dist_from_center creation
        ws_vars.proc_L=(ws_vars.proc_L//2)*2
        ws_vars.proc_R=(ws_vars.proc_R//2)*2
        ws_vars.proc_T=(ws_vars.proc_T//2)*2
        ws_vars.proc_B=(ws_vars.proc_B//2)*2
           
        section_X=slice(int(ws_vars.proc_L),int(ws_vars.proc_R))
        section_Y=slice(int(ws_vars.proc_T),int(ws_vars.proc_B))

        #prepare the dist from center for denoising
        deltaX=ws_vars.proc_R-ws_vars.proc_L
        deltaY=ws_vars.proc_B-ws_vars.proc_T

        halfX= base.shape[1]//2
        halfY= base.shape[0]//2

        dsection_X=slice(int(halfX-deltaX//2),int(halfX+deltaX//2))
        dsection_Y=slice(int(halfY-deltaY//2),int(halfY+deltaY//2))
        
        dist_from_center=odist_from_center[dsection_Y,dsection_X]
    else: #full image
        section_X=slice(0,base.shape[1])
        section_Y=slice(0,base.shape[0])
        dist_from_center=odist_from_center
    return section_X,section_Y, dist_from_center
            

 #Initial routine setting all default global variables     
 

memimg_loaded=False
try:
    #image dimensions
    print(ws_vars.difdimy)
    print(ws_vars.difdimx)
    verbose=False
    
    #original image
    mem_image=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.uint16)
   
    #output images  
    disp_image=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.uint16)  
    #graph for denoise
    graph_image=np.zeros((400,800,3)).astype(np.uint16)
    #processed outputimage
    out_image=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)

    #storage for blurring routines
    #original RGB
    base=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    #original as colourmodel
    ccBase=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    #active colourmodel
    ccModel=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    #default blur (index0 = HSL)
    blur_func=blurfunctions[0]
    
    #main storage for sharpener
    # unsharpened background 
    blur3=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    #differential layers
    highpass1=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    highpass2=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    highpass3=np.zeros((ws_vars.difdimy,ws_vars.difdimx,3)).astype(np.float32)
    
    #histogram storage
    nbins=1000
    b_hist=np.zeros(nbins).astype(np.float32)
    g_hist=np.zeros(nbins).astype(np.float32)
    r_hist=np.zeros(nbins).astype(np.float32)
    l_hist=np.zeros(nbins).astype(np.float32)
    #default tone controls    
    lum=toneControl(name='lum',m=0.5)
    sat=toneControl(name='sat',m=0.5)
    redtone=toneControl(name='red',m=0.5)
    greentone=toneControl(name='green',m=0.5)
    bluetone=toneControl(name='blue',m=0.5)
     
    ws_vars.clipLo=0
    ws_vars.clipHi=65535

    print('image initialized')
    print(mem_image.shape)
    print('sum',mem_image.sum())
    mem_image_loaded=True
    ws_vars.pythonVersion=str(sys.version).split(' (')[0]
    print(ws_vars.pythonVersion)
    odist_from_center=create_dist_from_center(mem_image[:,:,0])
    dist_from_center=odist_from_center
        
   
except:
  print('image NOT initialized')
  


