
import cv2
import numpy as np

from dataclasses import dataclass

redConversion=0.299
greenConversion=0.587
blueConversion=0.114

def rgb2HLS(base):
    ccBase = cv2.cvtColor(base, cv2.COLOR_BGR2HLS)
    ccBase[:,:,1]= base[:,:,0]*redConversion+base[:,:,1]*greenConversion+base[:,:,2]*blueConversion
    return ccBase
    
def HLS2rgb(img):
    return cv2.cvtColor(img, cv2.COLOR_HLS2BGR)

#************************    

def rgb2HSV(base): 
    ccBase = cv2.cvtColor(base, cv2.COLOR_BGR2HSV)
    ccBase[:,:,2]=base[:,:,0]*redConversion+base[:,:,1]*greenConversion+base[:,:,2]*blueConversion
    return ccBase

def HSV2rgb(img):
    return cv2.cvtColor(img, cv2.COLOR_HSV2BGR)
   
#************************

def linear_srgb_to_oklab(c):
       
    l=  0.4122214708 * c[:,:,2] + 0.5363325363 * c[:,:,1] + 0.0514459929 * c[:,:,0]
    m=  0.2119034982 * c[:,:,2] + 0.6806995451 * c[:,:,1] + 0.1073969566 * c[:,:,0]
    s=  0.0883024619 * c[:,:,2] + 0.2817188376 * c[:,:,1] + 0.6299787005 * c[:,:,0]

    l_ = l**(1./3.)
    m_ = m**(1./3.)
    s_ = s**(1./3.)
      
    okL=	0.2104542553*l_ + 0.7936177850*m_ - 0.0040720468*s_
    oka=	1.9779984951*l_ - 2.4285922050*m_ + 0.4505937099*s_
    okb=	0.0259040371*l_ + 0.7827717662*m_ - 0.8086757660*s_

    outmodel=c.copy()
    outmodel[:,:,0]=np.power(okL,2.4)
    outmodel[:,:,1]=oka
    outmodel[:,:,2]=okb

    return outmodel

#@njit(parallel=True)
def oklab_to_linear_srgb(c):
    g=1/2.4
    c[:,:,0]=np.clip(c[:,:,0],0,1)

    c[:,:,0]=np.power(c[:,:,0],g) 
  
    l_ = c[:,:,0] + 0.3963377774 * c[:,:,1] + 0.2158037573 * c[:,:,2]
    m_ = c[:,:,0] - 0.1055613458 * c[:,:,1] - 0.0638541728 * c[:,:,2]
    s_ = c[:,:,0] - 0.0894841775 * c[:,:,1] - 1.2914855480 * c[:,:,2]

    l = l_*l_*l_
    m = m_*m_*m_
    s = s_*s_*s_

    rgb=c.copy()
    rgb[:,:,2]=+4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    rgb[:,:,1]=-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    rgb[:,:,0]=-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s    

    return rgb

fromRGBfunc=[rgb2HSV,rgb2HLS,linear_srgb_to_oklab]

toRGBfunc=[HSV2rgb,HLS2rgb,oklab_to_linear_srgb]
#************************

def convertRGB(img, activeColourModel):
     return fromRGBfunc[activeColourModel.toRGB_idx](img)

def rebuildRGB(img, activeColourModel):
     return toRGBfunc[activeColourModel.toRGB_idx](img)

@dataclass
class col_conversion_setup:
    name:str ='OKlab'
    L:int =0
    S:int =1
    fromRGB_idx:int= 2
    toRGB_idx: int=2

