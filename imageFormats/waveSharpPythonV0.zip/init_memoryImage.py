import laz_vars as vars

gauss=2.35*np.sqrt(np.pi)

def showmem():
    cv2.imshow('mem_image',mem_image)

def showdisp():
    cv2.imshow('disp_image',disp_image)

def showout():
    cv2.imshow('image',out_image)

def setBase():
      global mem_image,base 
      base=mem_image.astype('float32')
      vars.clipLo=base.min()
      vars.clipHi=base.max()

def setdisp():
    global out_image
    disp_image=out_image.copy()
    disp_image*=65535
    disp_image=disp_image.astype(np.uint16)
    print('dispsum',disp_image.sum())
    return disp_image

def sharpen():
    global base, out_image, mem_image, blur1,blur2, blur3, highpass1, highpass2, highpass3
    gaussian_kernel=0
    gaussian_sigma1=vars.sigma1*gauss #conversion between wavesharp and cv2 gaussian
    gaussian_sigma2=vars.sigma2*gauss #conversion between wavesharp and cv2 gaussian
    gaussian_sigma3=vars.sigma3*gauss #conversion between wavesharp and cv2 gaussian
    
    #convert original to F32bit
    if vars.filterchange:
        blur1=cv2.GaussianBlur(base,(gaussian_kernel, gaussian_kernel),gaussian_sigma1 ,).astype('float32')
        highpass1=cv2.subtract(base,blur1).astype('float32')
        blur2=cv2.GaussianBlur(blur1,(gaussian_kernel, gaussian_kernel),gaussian_sigma2 ,).astype('float32')
        highpass2=cv2.subtract(blur1,blur2).astype('float32')
        blur3=cv2.GaussianBlur(blur2,(gaussian_kernel, gaussian_kernel),gaussian_sigma3 ,).astype('float32')
        highpass3=cv2.subtract(blur2,blur3).astype('float32')

    vars.filterchange=False    
    out_image =cv2.addWeighted(base, 1,  highpass1,vars.sharpen1, 0)
    if vars.sharpen2>0:
        out_image=cv2.addWeighted(out_image, 1,  highpass2,vars.sharpen2, 0)
    if vars.sharpen3>0:
        out_image =cv2.addWeighted(out_image, 1,  highpass3,vars.sharpen3, 0)
   
    #out_image=np.clip(out_image,vars.clipLo,vars.clipHi)
    #out_image= cv2.normalize(out_image,None,0,65535,cv2.NORM_MINMAX)
    # print('checksum out_image ',out_image.sum())
    # print('out_image Lo',vars.clipLo)
    # print('out_image Hi',vars.clipHi)
       
    
    # #out_image=highpass
    # print('sharpen done')

memimg_loaded=False
try:
  print(vars.difdimy)
  print(vars.difdimx)
  mem_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.uint16)  
  
  disp_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.uint16)  
  base=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  out_image=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  blur1=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  blur2=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  blur3=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  highpass1=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  highpass2=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  highpass3=np.zeros((vars.difdimy,vars.difdimx,3)).astype(np.float32)
  vars.clipLo=0
  vars.clipHi=65535
  print('image initialized')
  print(mem_image.shape)
  print('sum',mem_image.sum())
  mem_image_loaded=True

except:
  print('image NOT initialized')


