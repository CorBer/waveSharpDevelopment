
library_test.value='' 
try:
   import cv2
   print('OpenCV installed')
   
except:
   print('OpenCV NOT installed')
   library_test.value+=' OPENCV'

try: 
   import numpy as np
   print('Numpy installed')
except:
  print('Numpy NOT installed')  
  library_test.value+=' NUMPY'

if len(library_test.value)>2:
   library_test.value='missing '+library_test.value
else:
   library_test.value='OK'

